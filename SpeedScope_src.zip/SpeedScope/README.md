# SpeedScope

An Android network tool built with Kotlin and Jetpack Compose. It measures real-world speed, watches your connection over hours, and exports clear reports.

Package: `com.speedscope.app` · min SDK 26 · target SDK 34

## What it does

| Tab | Purpose |
|-----|---------|
| **Speed** | One-tap test: 10 s download, 10 s upload, idle ping and ping under load, jitter. Live gauge and chart. |
| **Long Run** | Minutes to hours (up to 24 h). Four modes: Download, Upload, Both (simultaneous), Sequential (download then upload, each with its own duration). Keeps running with the screen off. |
| **Monitor** | Ping monitor. ICMP with TCP:443 fallback. 3 or more failed probes in a row = outage. Availability %, latency stats, outage list, and an automatic gateway / internet / DNS comparison when an outage starts. |
| **Tools** | Latency (gateway, internet, DNS), Wi-Fi signal, Wi-Fi scan with channel crowding, Video check (best streaming quality your line can hold). History and server selection are reachable from here too. |

Every finished run can be exported as a **PDF** (A4, multi-page) or a **PNG** image and shared from the system share sheet.

## Measurement notes

- HTTP/1.1 only: HTTP/2 would multiplex all "parallel" connections over one socket and make the multi-connection setting meaningless.
- Multi (10 download / 4 upload connections) or Single (1/1).
- Servers: Cloudflare (`speed.cloudflare.com`), Ookla servers found through search or "near me", or any custom HTTP(S) URL.
- Ping uses its own HTTP client so it is never queued behind speed-test sockets.
- "Steady average" ignores the first 3 seconds (TCP slow start).
- **Boost check** compares the first 30 s with everything after 40 s. The wording is always "observed performance reduction", never "throttling proved": a drop can come from the server, Wi-Fi, congestion or ISP policy.
- Monitor availability = successful probes / total probes. Paused time is excluded because no probes are sent while paused.
- Video check uses the slowest 10% of seconds (P10) with 25% headroom over each quality's bitrate, not the average.

## Build

### On GitHub (no local setup)

1. Push this folder to a GitHub repository (branch `main` or `master`).
2. Open the **Actions** tab. The *Build SpeedScope APK* workflow runs the unit tests, then builds the debug APK.
3. Download the `SpeedScope-debug-apk` artifact from the finished run.

If a run fails, open the log of the failed step. Test reports are uploaded as the `test-reports` artifact.

### Locally

Android Studio (Koala or newer) or JDK 17 + Gradle 8.9:

```
gradle :app:testDebugUnitTest
gradle :app:assembleDebug
```

The APK is written to `app/build/outputs/apk/debug/`.

## Project layout

```
app/src/main/java/com/speedscope/app/
  MainActivity.kt        bottom navigation and pushed screens
  data/                  models, statistics, preferences, report JSON, history, video ladder
  engine/                SpeedEngine (HTTP load), TestService (foreground), servers, ping / Wi-Fi tools
  monitor/               IncidentDetector (pure logic), MonitorDb (SQLite), MonitorService, HopAnalyzer
  report/                PDF / PNG renderer and share helper
  ui/                    Compose screens and shared components
app/src/test/            unit tests for statistics, incident detection and the video ladder
```

Design choices worth knowing:

- Plain `SQLiteOpenHelper` instead of Room, so there is no annotation-processing step to break the build.
- Logic that can be tested without Android (`Stats.kt`, `Video.kt`, `IncidentDetector.kt`, `Models.kt`) has no Android imports.
- Foreground services: `TestService` (data sync) and `MonitorService` (special use on Android 14+, data sync below).
- Only the last 30 speed reports are kept; monitor sessions stay until you delete them.

## Permissions

Internet and network state for testing. Location is optional and only needed for the Wi-Fi name, Wi-Fi scan and "near me" server search (Android requirement). Notifications are used for the foreground services and for outage / result alerts.

## Limitations

- Android only. The app cannot see what your ISP does with traffic; it reports what it measures.
- ICMP may be blocked by some networks; the monitor then falls back to TCP:443 and shows which method it used.
- Android limits Wi-Fi scans to a few per two minutes.
