package com.speedscope.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.speedscope.app.data.*
import com.speedscope.app.monitor.MonitorDb
import com.speedscope.app.monitor.MonitorState
import com.speedscope.app.monitor.SessionRow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
private fun TestRow(r: Report, unit: SpeedUnit, onOpen: () -> Unit, onDelete: () -> Unit) {
    val dn = statsOf(steady(r.downValues())).avg
    val up = statsOf(steady(r.upValues())).avg
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(C.Card)
            .clickable { onOpen() }.padding(start = 14.dp, top = 10.dp, bottom = 10.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Row {
                Text(kindLabel(r.kind), color = C.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                if (r.partial) Text("  partial", color = C.Orange, fontSize = 12.sp)
            }
            Label(fmtTime(r.startedAt) + "  ·  " + fmtDur(r.samples.size) + "  ·  " + r.mode.label)
            Gap(4.dp)
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                if (r.hasDown) Text("↓ " + fmtSpeed(dn, unit) + " " + unit.label, color = C.Green, fontSize = 13.sp)
                if (r.hasUp) Text("↑ " + fmtSpeed(up, unit) + " " + unit.label, color = C.Orange, fontSize = 13.sp)
                if (r.idlePingMs >= 0) Text(fmtMs(r.idlePingMs), color = C.Purple, fontSize = 13.sp)
            }
        }
        TextButton(onClick = onDelete) { Text("✕", color = C.Muted) }
    }
}

@Composable
private fun SessionItem(s: SessionRow, active: Boolean, onOpen: () -> Unit, onDelete: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(C.Card)
            .clickable { onOpen() }.padding(start = 14.dp, top = 10.dp, bottom = 10.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Row {
                Text("Ping: " + s.target, color = C.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                if (active) Text("  running", color = C.Green, fontSize = 12.sp)
            }
            Label(fmtTime(s.startedAt) + "  ·  " + fmtDur((s.durationMs / 1000).toInt()))
            Gap(4.dp)
            Text(f2(s.availability) + " % up  ·  " + s.ok + "/" + s.total + " probes", color = C.Purple, fontSize = 13.sp)
        }
        if (!active) TextButton(onClick = onDelete) { Text("✕", color = C.Muted) }
    }
}

@Composable
fun HistoryScreen(ui: UiPrefs, onBack: () -> Unit, onOpenReport: (String) -> Unit, onOpenSession: (Long) -> Unit) {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var version by remember { mutableIntStateOf(0) }
    var delTest by remember { mutableStateOf<String?>(null) }
    var delSession by remember { mutableStateOf<Long?>(null) }
    val mon by MonitorState.live.collectAsState()

    val tests by produceState<List<Report>?>(null, version) { value = withContext(Dispatchers.IO) { History.list(ctx) } }
    val sessions by produceState<List<SessionRow>?>(null, version) { value = withContext(Dispatchers.IO) { MonitorDb.get(ctx).sessions() } }

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ScreenHeader("History", onBack)
        Segmented(listOf(0, 1), tab, { if (it == 0) "Speed tests" else "Monitor sessions" }) { tab = it }
        if (tab == 0) {
            val list = tests
            if (list == null) Label("Loading…")
            else if (list.isEmpty()) Panel { Body("No saved tests yet. The last 30 are kept.", color = C.Muted) }
            else for (r in list) TestRow(r, ui.unit, { onOpenReport(r.id) }, { delTest = r.id })
        } else {
            val list = sessions
            if (list == null) Label("Loading…")
            else if (list.isEmpty()) Panel { Body("No monitor sessions yet. Start one from the Monitor tab.", color = C.Muted) }
            else for (s in list) SessionItem(s, mon.running && mon.sessionId == s.id, { onOpenSession(s.id) }, { delSession = s.id })
        }
        Gap(24.dp)
    }

    if (delTest != null) {
        AlertDialog(
            onDismissRequest = { delTest = null },
            title = { Text("Delete this report?") },
            confirmButton = {
                TextButton({ delTest?.let { History.delete(ctx, it) }; delTest = null; version++ }) { Text("Delete", color = C.Red) }
            },
            dismissButton = { TextButton({ delTest = null }) { Text("Cancel") } }
        )
    }
    if (delSession != null) {
        AlertDialog(
            onDismissRequest = { delSession = null },
            title = { Text("Delete this monitor session?") },
            text = { Text("All probes and outages of the session will be removed.") },
            confirmButton = {
                TextButton({ delSession?.let { MonitorDb.get(ctx).delete(it) }; delSession = null; version++ }) { Text("Delete", color = C.Red) }
            },
            dismissButton = { TextButton({ delSession = null }) { Text("Cancel") } }
        )
    }
}
