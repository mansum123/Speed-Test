package com.speedscope.app.data

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor

data class Stat(
    val avg: Double, val min: Double, val max: Double,
    val median: Double, val p10: Double, val p95: Double, val n: Int
)

val EMPTY_STAT = Stat(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0)

fun percentile(sorted: List<Double>, p: Double): Double {
    if (sorted.isEmpty()) return 0.0
    val idx = (p / 100.0) * (sorted.size - 1)
    val lo = floor(idx).toInt()
    val hi = ceil(idx).toInt()
    return sorted[lo] + (sorted[hi] - sorted[lo]) * (idx - lo)
}

fun statsOf(v: List<Double>): Stat {
    if (v.isEmpty()) return EMPTY_STAT
    val s = v.sorted()
    return Stat(v.average(), s.first(), s.last(), percentile(s, 50.0), percentile(s, 10.0), percentile(s, 95.0), v.size)
}

/** Drops the first [warm] seconds (TCP slow-start / ramp-up) when there is enough data. */
fun steady(v: List<Double>, warm: Int = 3): List<Double> = if (v.size > warm + 2) v.drop(warm) else v

/** Mean absolute difference of consecutive pings (ms). Negative values (no reply) are ignored. */
fun jitter(pings: List<Double>): Double {
    val p = pings.filter { it >= 0 }
    if (p.size < 2) return 0.0
    var sum = 0.0
    for (i in 1 until p.size) sum += abs(p[i] - p[i - 1])
    return sum / (p.size - 1)
}

data class Boost(val first: Double, val after: Double, val dropPct: Double, val reduced: Boolean)

/**
 * Compares the first [firstSec] seconds with everything after [afterFrom] seconds.
 * Wording in UI must stay "observed performance reduction" - never "throttling proved".
 */
fun boostOf(v: List<Double>, firstSec: Int = 30, afterFrom: Int = 40, threshold: Double = 20.0): Boost? {
    if (v.size < afterFrom + 10) return null
    val first = v.take(firstSec).average()
    val after = v.drop(afterFrom).average()
    if (first <= 0.0) return null
    val drop = (first - after) / first * 100.0
    return Boost(first, after, drop, drop >= threshold)
}

/** Min/max bucket downsampling: keeps spikes and dips visible. Output size <= maxPts. */
fun downsampleMinMax(v: List<Double>, maxPts: Int): List<Double> {
    if (v.size <= maxPts || maxPts < 4) return v
    val buckets = maxPts / 2
    val out = ArrayList<Double>(buckets * 2)
    for (b in 0 until buckets) {
        val from = (b.toLong() * v.size / buckets).toInt()
        val to = ((b + 1).toLong() * v.size / buckets).toInt().coerceAtMost(v.size)
        if (from >= to) continue
        var iMin = from
        var iMax = from
        for (i in from until to) {
            if (v[i] < v[iMin]) iMin = i
            if (v[i] > v[iMax]) iMax = i
        }
        if (iMin == iMax) out.add(v[iMin])
        else if (iMin < iMax) { out.add(v[iMin]); out.add(v[iMax]) }
        else { out.add(v[iMax]); out.add(v[iMin]) }
    }
    return out
}

fun f0(x: Double): String = String.format(Locale.US, "%.0f", x)
fun f1(x: Double): String = String.format(Locale.US, "%.1f", x)
fun f2(x: Double): String = String.format(Locale.US, "%.2f", x)

fun fmtSpeed(mbps: Double, unit: SpeedUnit): String {
    val x = mbps * unit.perMbps
    return if (x >= 100) f0(x) else if (x >= 10) f1(x) else f2(x)
}

fun fmtMs(ms: Double): String = if (ms < 0) "–" else if (ms >= 100) f0(ms) + " ms" else f1(ms) + " ms"

fun fmtDur(sec: Int): String {
    val h = sec / 3600
    val m = (sec % 3600) / 60
    val s = sec % 60
    return when {
        h > 0 -> if (m > 0) "$h hr $m min" else "$h hr"
        m > 0 -> if (s > 0) "$m min $s s" else "$m min"
        else -> "$s s"
    }
}

fun fmtClock(sec: Int): String = String.format(Locale.US, "%d:%02d", sec / 60, sec % 60)

fun fmtTime(ms: Long): String = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date(ms))

fun fmtBytes(b: Long): String = when {
    b >= 1L shl 30 -> f2(b / 1073741824.0) + " GB"
    b >= 1L shl 20 -> f1(b / 1048576.0) + " MB"
    b >= 1L shl 10 -> f1(b / 1024.0) + " KB"
    else -> "$b B"
}
