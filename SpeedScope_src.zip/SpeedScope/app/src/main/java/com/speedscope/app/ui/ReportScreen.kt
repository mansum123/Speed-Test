package com.speedscope.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.speedscope.app.data.*
import com.speedscope.app.engine.Extras
import com.speedscope.app.engine.TestState
import com.speedscope.app.report.Blocks
import com.speedscope.app.report.ReportExporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

fun kindLabel(kind: String): String = when (kind) {
    "long" -> "Long Run"
    "video" -> "Video check"
    else -> "Speed Test"
}

/** Newest finished report of [kind]: the one just produced in this session, else the newest saved one. */
@Composable
fun rememberLatest(kind: String): Report? {
    val ctx = LocalContext.current
    val last by TestState.last.collectAsState()
    val l = last
    val matches = l != null && l.kind == kind
    val fromDisk by produceState<Report?>(null, kind, l?.id) {
        value = if (matches) null else withContext(Dispatchers.IO) { History.list(ctx).firstOrNull { it.kind == kind } }
    }
    return if (matches) l else fromDisk
}

private fun spd(v: Double, u: SpeedUnit) = fmtSpeed(v, u) + " " + u.label

/** PDF / PNG buttons. [onPdf] / [onPng] must build and share the file; [busy] disables both. */
@Composable
fun ExportRow(busy: Boolean, error: String?, onPdf: () -> Unit, onPng: () -> Unit) {
    Panel {
        Title("Export report")
        Gap(4.dp)
        Label("Creates a file and opens the share sheet (save to Files, WhatsApp, e-mail ...).")
        Gap(10.dp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            PrimaryButton(if (busy) "Working…" else "PDF", onPdf, Modifier.weight(1f), enabled = !busy)
            PrimaryButton(if (busy) "Working…" else "PNG image", onPng, Modifier.weight(1f), color = C.Teal, enabled = !busy)
        }
        if (error != null) { Gap(8.dp); Body(error, color = C.Red) }
    }
}

@Composable
private fun StatsPanel(title: String, values: List<Double>, color: androidx.compose.ui.graphics.Color, unit: SpeedUnit) {
    val s = statsOf(values)
    val st = statsOf(steady(values))
    Panel {
        Title(title)
        Gap(10.dp)
        StatGrid(listOf(
            "Average" to spd(s.avg, unit), "Steady avg (after 3 s)" to spd(st.avg, unit), "Peak" to spd(s.max, unit),
            "Minimum" to spd(s.min, unit), "Slowest 10% (P10)" to spd(st.p10, unit), "Median" to spd(s.median, unit)
        ))
    }
    ChartCard(
        "$title over time", listOf(Line(values.map { it * unit.perMbps }, color)),
        listOf(title to color), unit.label
    )
}

@Composable
private fun BoostPanel(name: String, b: Boost, unit: SpeedUnit) {
    Body(
        "$name: first 30 s average ${spd(b.first, unit)}, after 40 s ${spd(b.after, unit)} -> " +
            if (b.reduced) "observed performance reduction of ${f0(b.dropPct)}%." else "no significant reduction (${f0(b.dropPct)}% change)."
    )
}

/** Video quality ladder from the weak-moment speed (P10) of a download series. */
@Composable
fun VideoPanel(downMbps: List<Double>) {
    val weak = VideoLadder.weakSpeed(downMbps)
    val best = VideoLadder.best(downMbps)
    Panel {
        Title("Video streaming check")
        Gap(4.dp)
        Label("Based on the slowest 10% of seconds (${f1(weak)} Mbps), with 25% headroom over each quality's bitrate.")
        Gap(10.dp)
        Text(
            if (best != null) "Smooth up to ${best.label}" else "Too weak even for 240p",
            color = if (best != null) C.Green else C.Red, fontSize = 18.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
        )
        Gap(8.dp)
        for (q in VideoLadder.ladder.reversed()) {
            val ok = VideoLadder.supports(q, weak)
            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                Text(q.label, color = C.Text, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text("needs ${f1(q.needMbps * VideoLadder.HEADROOM)} Mbps", color = C.Muted, fontSize = 12.sp, modifier = Modifier.weight(1.4f))
                Text(if (ok) "OK" else "Not stable", color = if (ok) C.Green else C.Red, fontSize = 13.sp)
            }
        }
    }
}

/** Everything about one finished run (used under the live view and in the detail screen). */
@Composable
fun ReportBody(r: Report, unit: SpeedUnit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Panel {
            Title(kindLabel(r.kind) + " - " + r.mode.label)
            Gap(4.dp)
            Label(fmtTime(r.startedAt) + "  ·  " + fmtDur(r.samples.size) + " measured  ·  " + r.conn.label)
            Label(r.server + if (r.serverLoc.isNotBlank()) " - " + r.serverLoc else "")
        }
        if (r.partial) Notice("This run was stopped early or hit an error, so the result is partial.")

        if (r.hasDown) StatsPanel("Download", r.downValues(), C.Green, unit)
        if (r.hasUp) StatsPanel("Upload", r.upValues(), C.Orange, unit)

        val pv = r.pings()
        Panel {
            Title("Latency")
            Gap(10.dp)
            StatGrid(listOf(
                "Idle ping" to fmtMs(r.idlePingMs),
                "Under load (avg)" to (if (pv.isEmpty()) "–" else fmtMs(pv.average())),
                "Jitter" to (if (pv.size < 2) "–" else fmtMs(jitter(pv)))
            ))
        }
        if (pv.size >= 2) ChartCard("Ping under load", listOf(Line(pv, C.Purple)), listOf("Ping" to C.Purple), "ms")

        val bd = if (r.hasDown) boostOf(r.downValues()) else null
        val bu = if (r.hasUp) boostOf(r.upValues()) else null
        if (bd != null || bu != null) {
            Panel {
                Title("Boost check")
                Gap(6.dp)
                if (bd != null) BoostPanel("Download", bd, unit)
                if (bu != null) BoostPanel("Upload", bu, unit)
                Gap(6.dp)
                Label("An observed reduction after the first seconds can have many causes (server, Wi-Fi, congestion, ISP policy). It is an observation, not proof of throttling.")
            }
        }

        if (r.hasDown && r.kind != "video") VideoPanel(r.downValues())

        val s = r.snap
        Panel {
            Title("Network snapshot (at start)")
            Gap(10.dp)
            StatGrid(listOf(
                "Connection" to s.type.ifBlank { "–" },
                "Wi-Fi name" to s.ssid.ifBlank { "–" },
                "Signal" to (if (s.rssi != 0) "${s.rssi} dBm" else "–"),
                "Link speed" to (if (s.linkMbps > 0) "${s.linkMbps} Mbps" else "–"),
                "Band / channel" to (if (s.freqMhz > 0) "${com.speedscope.app.engine.bandOf(s.freqMhz)} / ch ${com.speedscope.app.engine.chanOf(s.freqMhz)}" else "–"),
                "Gateway" to s.gateway.ifBlank { "–" },
                "Gateway latency" to fmtMs(s.gatewayMs),
                "DNS lookup" to fmtMs(s.dnsMs)
            ))
        }
        val ex = Extras.lines()
        if (ex.isNotEmpty()) {
            Panel {
                Title("Other tools (included in export)")
                Gap(6.dp)
                for (line in ex) Body(line, color = C.Muted)
            }
        }
    }
}

/** Full-screen detail with export + delete. */
@Composable
fun ReportDetailScreen(r: Report, unit: SpeedUnit, onBack: () -> Unit, onDeleted: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var confirm by remember { mutableStateOf(false) }

    fun export(png: Boolean) {
        scope.launch {
            busy = true; error = null
            try {
                val file = withContext(Dispatchers.IO) {
                    val blocks = Blocks.speed(r, unit)
                    val name = ReportExporter.fileName(r.kind, r.startedAt, if (png) "png" else "pdf")
                    if (png) ReportExporter.png(ctx, blocks, name) else ReportExporter.pdf(ctx, blocks, name)
                }
                ReportExporter.share(ctx, file, if (png) "image/png" else "application/pdf")
            } catch (e: Exception) {
                error = "Export failed: " + (e.message ?: e.javaClass.simpleName)
            } finally { busy = false }
        }
    }

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader(kindLabel(r.kind), onBack) {
            SoftButton("Delete", { confirm = true }, color = C.Red)
        }
        ExportRow(busy, error, { export(false) }, { export(true) })
        ReportBody(r, unit)
        Gap(24.dp)
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Delete this report?") },
            text = { Text("It will be removed from History.") },
            confirmButton = {
                TextButton({ confirm = false; History.delete(ctx, r.id); onDeleted() }) { Text("Delete", color = C.Red) }
            },
            dismissButton = { TextButton({ confirm = false }) { Text("Cancel") } }
        )
    }
}
