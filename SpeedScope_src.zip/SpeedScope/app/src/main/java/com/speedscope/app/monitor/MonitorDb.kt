package com.speedscope.app.monitor

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.speedscope.app.data.Stat
import com.speedscope.app.data.statsOf

data class Probe(val t: Long, val rtt: Double)   // rtt < 0 = failed

data class SessionRow(
    val id: Long, val startedAt: Long, val endedAt: Long, val target: String, val intervalMs: Long,
    val total: Int, val ok: Int, val dropped: Int, val method: String
) {
    val availability: Double get() = if (total == 0) 100.0 else ok * 100.0 / total
    val durationMs: Long get() = (if (endedAt > 0) endedAt else System.currentTimeMillis()) - startedAt
}

data class IncidentRow(val startMs: Long, val endMs: Long, val fails: Int, val beforeMs: Double, val afterMs: Double, val diag: String)

data class Bucket(val avg: Double, val max: Double, val fails: Int, val count: Int)

/** Plain SQLite (no Room/KSP): sessions, probes (batch inserted), incidents. */
class MonitorDb private constructor(ctx: Context) : SQLiteOpenHelper(ctx, "monitor.db", null, 1) {
    companion object {
        @Volatile private var inst: MonitorDb? = null
        fun get(ctx: Context): MonitorDb =
            inst ?: synchronized(this) { inst ?: MonitorDb(ctx.applicationContext).also { inst = it } }
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE sessions(id INTEGER PRIMARY KEY AUTOINCREMENT, startedAt INTEGER, endedAt INTEGER, target TEXT, intervalMs INTEGER, total INTEGER, ok INTEGER, dropped INTEGER, method TEXT)")
        db.execSQL("CREATE TABLE probes(session INTEGER, t INTEGER, rtt REAL)")
        db.execSQL("CREATE INDEX probes_s ON probes(session, t)")
        db.execSQL("CREATE TABLE incidents(session INTEGER, startMs INTEGER, endMs INTEGER, fails INTEGER, beforeMs REAL, afterMs REAL, diag TEXT)")
    }

    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}

    fun startSession(target: String, intervalMs: Long): Long {
        val cv = ContentValues()
        cv.put("startedAt", System.currentTimeMillis()); cv.put("endedAt", 0L); cv.put("target", target)
        cv.put("intervalMs", intervalMs); cv.put("total", 0); cv.put("ok", 0); cv.put("dropped", 0); cv.put("method", "")
        return writableDatabase.insert("sessions", null, cv)
    }

    fun insertProbes(session: Long, list: List<Probe>) {
        if (list.isEmpty()) return
        val db = writableDatabase
        db.beginTransaction()
        try {
            val st = db.compileStatement("INSERT INTO probes(session,t,rtt) VALUES(?,?,?)")
            for (p in list) {
                st.clearBindings(); st.bindLong(1, session); st.bindLong(2, p.t); st.bindDouble(3, p.rtt); st.executeInsert()
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun saveIncidents(session: Long, list: List<Incident>) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("incidents", "session=?", arrayOf(session.toString()))
            for (i in list) {
                val cv = ContentValues()
                cv.put("session", session); cv.put("startMs", i.startMs); cv.put("endMs", i.endMs ?: -1L)
                cv.put("fails", i.fails); cv.put("beforeMs", i.beforeMs ?: -1.0); cv.put("afterMs", i.afterMs ?: -1.0)
                cv.put("diag", i.diag ?: "")
                db.insert("incidents", null, cv)
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun updateSession(id: Long, total: Int, ok: Int, dropped: Int, method: String, endedAt: Long = 0L) {
        val cv = ContentValues()
        cv.put("total", total); cv.put("ok", ok); cv.put("dropped", dropped); cv.put("method", method)
        if (endedAt > 0) cv.put("endedAt", endedAt)
        writableDatabase.update("sessions", cv, "id=?", arrayOf(id.toString()))
    }

    private fun row(c: android.database.Cursor) = SessionRow(
        c.getLong(0), c.getLong(1), c.getLong(2), c.getString(3) ?: "", c.getLong(4),
        c.getInt(5), c.getInt(6), c.getInt(7), c.getString(8) ?: ""
    )

    private val cols = "id,startedAt,endedAt,target,intervalMs,total,ok,dropped,method"

    fun sessions(): List<SessionRow> {
        val out = ArrayList<SessionRow>()
        readableDatabase.rawQuery("SELECT $cols FROM sessions ORDER BY id DESC", null).use { c -> while (c.moveToNext()) out.add(row(c)) }
        return out
    }

    fun session(id: Long): SessionRow? =
        readableDatabase.rawQuery("SELECT $cols FROM sessions WHERE id=$id", null).use { c -> if (c.moveToFirst()) row(c) else null }

    fun incidents(id: Long): List<IncidentRow> {
        val out = ArrayList<IncidentRow>()
        readableDatabase.rawQuery("SELECT startMs,endMs,fails,beforeMs,afterMs,diag FROM incidents WHERE session=$id ORDER BY startMs", null).use { c ->
            while (c.moveToNext()) out.add(IncidentRow(c.getLong(0), c.getLong(1), c.getInt(2), c.getDouble(3), c.getDouble(4), c.getString(5) ?: ""))
        }
        return out
    }

    fun rtts(id: Long): List<Double> {
        val out = ArrayList<Double>()
        readableDatabase.rawQuery("SELECT rtt FROM probes WHERE session=$id AND rtt>=0 ORDER BY t", null).use { c -> while (c.moveToNext()) out.add(c.getDouble(0)) }
        return out
    }

    fun rttStats(id: Long): Stat = statsOf(rtts(id))

    /** Graph data computed in SQL: at most [n] buckets, no matter how many probes. */
    fun buckets(id: Long, n: Int = 300): List<Bucket> {
        val db = readableDatabase
        var minT = 0L; var maxT = 0L
        db.rawQuery("SELECT MIN(t), MAX(t) FROM probes WHERE session=$id", null).use { c -> if (c.moveToFirst() && !c.isNull(0)) { minT = c.getLong(0); maxT = c.getLong(1) } }
        if (maxT == 0L) return emptyList()
        val width = maxT - minT + 1
        val out = ArrayList<Bucket>()
        val sql = "SELECT ((t-$minT)*$n)/$width AS b, AVG(CASE WHEN rtt>=0 THEN rtt END), MAX(rtt), " +
            "SUM(CASE WHEN rtt<0 THEN 1 ELSE 0 END), COUNT(*) FROM probes WHERE session=$id GROUP BY b ORDER BY b"
        db.rawQuery(sql, null).use { c ->
            while (c.moveToNext()) out.add(Bucket(if (c.isNull(1)) -1.0 else c.getDouble(1), c.getDouble(2), c.getInt(3), c.getInt(4)))
        }
        return out
    }

    fun delete(id: Long) {
        val db = writableDatabase
        db.delete("probes", "session=?", arrayOf(id.toString()))
        db.delete("incidents", "session=?", arrayOf(id.toString()))
        db.delete("sessions", "id=?", arrayOf(id.toString()))
    }
}
