package com.speedscope.app.engine

import android.os.SystemClock
import com.speedscope.app.data.*
import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okio.BufferedSink
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference
import kotlin.random.Random

object Http {
    private const val UA = "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

    /** Browser-like headers: okhttp's default User-Agent gets HTTP 403 from Cloudflare / speedtest.net bot rules. */
    private val browserHeaders = Interceptor { chain ->
        val req = chain.request()
        val host = req.url.host
        val b = req.newBuilder().header("User-Agent", UA).header("Accept", "*/*").header("Accept-Language", "en-US,en;q=0.9")
        if (host.endsWith("cloudflare.com")) {
            b.header("Origin", "https://speed.cloudflare.com").header("Referer", "https://speed.cloudflare.com/")
        } else if (host.endsWith("speedtest.net")) {
            b.header("Referer", "https://www.speedtest.net/")
        }
        chain.proceed(b.build())
    }

    /** HTTP/1.1 only: HTTP/2 would multiplex all "parallel" connections over ONE socket. */
    private fun speedBuilder() = OkHttpClient.Builder()
        .protocols(listOf(Protocol.HTTP_1_1))
        .connectionPool(ConnectionPool(32, 5, TimeUnit.MINUTES))
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .addInterceptor(browserHeaders)

    val speed: OkHttpClient by lazy { speedBuilder().build() }
    /** Separate client + pool so ping is not queued behind speed-test sockets. */
    val ping: OkHttpClient by lazy {
        speedBuilder().connectionPool(ConnectionPool(2, 2, TimeUnit.MINUTES))
            .connectTimeout(4, TimeUnit.SECONDS).readTimeout(4, TimeUnit.SECONDS).build()
    }
    val api: OkHttpClient by lazy {
        OkHttpClient.Builder().connectTimeout(10, TimeUnit.SECONDS).readTimeout(10, TimeUnit.SECONDS).addInterceptor(browserHeaders).build()
    }
}

object SpeedEngine {

    /** Blocking HTTP latency probe (time to first byte). Null on failure. */
    fun httpPing(url: String): Double? = try {
        val req = Request.Builder().url(Servers.bust(url)).header("Cache-Control", "no-cache").build()
        val t0 = System.nanoTime()
        Http.ping.newCall(req).execute().use { r ->
            r.body?.source()?.read(ByteArray(64))
            if (!r.isSuccessful) null else (System.nanoTime() - t0) / 1e6
        }
    } catch (e: Exception) { null }

    /** Median of a few idle probes (first one is warm-up and dropped). */
    suspend fun idlePing(ep: Endpoints, n: Int = 6): Double = withContext(Dispatchers.IO) {
        val v = ArrayList<Double>()
        repeat(n) { httpPing(ep.ping)?.let { v.add(it) }; delay(120) }
        if (v.size > 1) statsOf(v.drop(1)).median else if (v.isNotEmpty()) v[0] else -1.0
    }

    suspend fun run(cfg: RunConfig, ep: Endpoints, onSample: (Sample, Int, Phase) -> Unit) {
        val phases = Plans.build(cfg.mode, cfg.durSec, cfg.upSec)
        var t = 0
        for ((i, ph) in phases.withIndex()) {
            t = runPhase(ph, ep, cfg.conn, t) { s -> onSample(s, i, ph) }
        }
    }

    private suspend fun runPhase(ph: Phase, ep: Endpoints, conn: ConnType, t0: Int, emit: (Sample) -> Unit): Int =
        coroutineScope {
            val client = Http.speed
            val dBytes = AtomicLong()
            val uBytes = AtomicLong()
            val lastPing = AtomicLong((-1.0).toRawBits())
            val err = AtomicReference<String?>(null)
            val calls = ConcurrentHashMap.newKeySet<Call>()
            val jobs = ArrayList<Job>()

            if (ph.dir != Dir.UP) repeat(conn.down) {
                jobs.add(launch(Dispatchers.IO) { downloadLoop(client, ep.down, dBytes, calls, err) { isActive } })
            }
            if (ph.dir != Dir.DOWN) repeat(conn.up) {
                jobs.add(launch(Dispatchers.IO) { uploadLoop(client, ep.up, uBytes, calls, err) { isActive } })
            }
            jobs.add(launch(Dispatchers.IO) {
                while (isActive) {
                    httpPing(ep.ping)?.let { lastPing.set(it.toRawBits()) }
                    delay(1000)
                }
            })

            val start = SystemClock.elapsedRealtime()
            var lastD = 0L
            var lastU = 0L
            var lastAt = start
            try {
                for (sec in 1..ph.seconds) {
                    delay(maxOf(0L, start + sec * 1000L - SystemClock.elapsedRealtime()))
                    val now = SystemClock.elapsedRealtime()
                    val d = dBytes.get()
                    val u = uBytes.get()
                    val dt = maxOf(0.001, (now - lastAt) / 1000.0)
                    emit(Sample(t0 + sec, (d - lastD) * 8 / 1e6 / dt, (u - lastU) * 8 / 1e6 / dt, Double.fromBits(lastPing.get())))
                    lastD = d; lastU = u; lastAt = now
                }
            } finally {
                jobs.forEach { it.cancel() }
                calls.forEach { it.cancel() }
            }
            if (dBytes.get() + uBytes.get() == 0L) throw IOException(err.get() ?: "No data transferred - check server / connection")
            t0 + ph.seconds
        }

    private fun snippet(resp: Response): String = try {
        val s = resp.peekBody(200).string().replace(Regex("\\s+"), " ").trim()
        if (s.isEmpty()) "" else " ($s)"
    } catch (e: Exception) { "" }

    private fun downloadLoop(
        client: OkHttpClient, url: String, counter: AtomicLong, calls: MutableSet<Call>,
        err: AtomicReference<String?>, alive: () -> Boolean
    ) {
        val buf = ByteArray(64 * 1024)
        while (alive()) {
            val call = client.newCall(Request.Builder().url(Servers.bust(url)).header("Cache-Control", "no-cache").build())
            calls.add(call)
            try {
                call.execute().use { resp ->
                    if (!resp.isSuccessful) {
                        err.set("Server returned HTTP ${resp.code}" + snippet(resp))
                        Thread.sleep(500)
                    } else {
                        val src = resp.body!!.source()
                        while (alive()) {
                            val n = src.read(buf)
                            if (n < 0) break
                            counter.addAndGet(n.toLong())
                        }
                    }
                }
            } catch (e: Exception) {
                if (alive()) { err.set(e.message ?: e.javaClass.simpleName); Thread.sleep(300) }
            } finally {
                calls.remove(call)
            }
        }
    }

    private fun uploadLoop(
        client: OkHttpClient, url: String, counter: AtomicLong, calls: MutableSet<Call>,
        err: AtomicReference<String?>, alive: () -> Boolean
    ) {
        val chunk = ByteArray(64 * 1024).also { Random.nextBytes(it) }
        val total = 4L * 1024 * 1024
        val body = object : RequestBody() {
            override fun contentType() = "application/octet-stream".toMediaType()
            override fun contentLength() = total
            override fun writeTo(sink: BufferedSink) {
                var left = total
                while (left > 0) {
                    if (!alive()) throw IOException("stopped")
                    val n = minOf(left, chunk.size.toLong()).toInt()
                    sink.write(chunk, 0, n)
                    counter.addAndGet(n.toLong())
                    left -= n
                }
            }
        }
        while (alive()) {
            val call = client.newCall(Request.Builder().url(Servers.bust(url)).post(body).build())
            calls.add(call)
            try {
                call.execute().use { resp ->
                    if (!resp.isSuccessful) {
                        err.set("Server returned HTTP ${resp.code} for upload" + snippet(resp))
                        Thread.sleep(500)
                    } else {
                        resp.body?.close()
                    }
                }
            } catch (e: Exception) {
                if (alive()) { err.set(e.message ?: e.javaClass.simpleName); Thread.sleep(300) }
            } finally {
                calls.remove(call)
            }
        }
    }
}
