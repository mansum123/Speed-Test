package com.speedscope.app.data

import android.content.Context
import com.speedscope.app.engine.Server
import com.speedscope.app.engine.Servers
import org.json.JSONObject

class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("speedscope", Context.MODE_PRIVATE)

    var unit: SpeedUnit
        get() = enumOr(sp.getString("unit", null), SpeedUnit.MBPS)
        set(v) { sp.edit().putString("unit", v.name).apply() }
    var scale: GaugeScale
        get() = enumOr(sp.getString("scale", null), GaugeScale.AUTO)
        set(v) { sp.edit().putString("scale", v.name).apply() }
    var conn: ConnType
        get() = enumOr(sp.getString("conn", null), ConnType.MULTI)
        set(v) { sp.edit().putString("conn", v.name).apply() }
    var mode: RunMode
        get() = enumOr(sp.getString("mode", null), RunMode.SEQUENTIAL)
        set(v) { sp.edit().putString("mode", v.name).apply() }
    var longSec: Int
        get() = sp.getInt("longSec", 300)
        set(v) { sp.edit().putInt("longSec", v).apply() }
    var longUpSec: Int
        get() = sp.getInt("longUpSec", 300)
        set(v) { sp.edit().putInt("longUpSec", v).apply() }
    var monTarget: String
        get() = sp.getString("monTarget", "8.8.8.8") ?: "8.8.8.8"
        set(v) { sp.edit().putString("monTarget", v).apply() }
    var monCustom: String
        get() = sp.getString("monCustom", "") ?: ""
        set(v) { sp.edit().putString("monCustom", v).apply() }
    var monIntervalSec: Int
        get() = sp.getInt("monInterval", 2)
        set(v) { sp.edit().putInt("monInterval", v).apply() }
    var server: Server
        get() = try { Servers.fromJson(JSONObject(sp.getString("server", "") ?: "")) } catch (e: Exception) { Servers.CF }
        set(v) { sp.edit().putString("server", Servers.toJson(v).toString()).apply() }
}
