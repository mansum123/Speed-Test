package com.speedscope.app.engine

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.SystemClock
import androidx.core.content.ContextCompat
import com.speedscope.app.data.NetSnap
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import java.net.ConnectException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.random.Random

data class Hop(val ttl: Int, val ip: String?, val rttMs: Double?, val reached: Boolean)

object PingTool {
    /** "ICMP" when the system ping binary works, otherwise "TCP:443" (a refused connection still proves the host is reachable). */
    @Volatile var method = "ICMP"
    @Volatile private var icmpBroken = false

    private val pool = Executors.newCachedThreadPool { r -> Thread(r).apply { isDaemon = true } }
    private val timeRe = Regex("time[=<]\\s*([0-9.]+)\\s*ms")

    fun <T> timeboxed(ms: Long, block: () -> T?): T? {
        val f = pool.submit(Callable<T?> { block() })
        return try { f.get(ms, TimeUnit.MILLISECONDS) } catch (e: Exception) { f.cancel(true); null }
    }

    private class IcmpResult(val understood: Boolean, val rtt: Double?)

    private fun icmp(host: String, timeoutMs: Int): IcmpResult {
        return try {
            val p = ProcessBuilder("/system/bin/ping", "-c", "1", "-W", ((timeoutMs + 999) / 1000).toString(), host)
                .redirectErrorStream(true).start()
            if (!p.waitFor(timeoutMs + 1500L, TimeUnit.MILLISECONDS)) {
                p.destroyForcibly()
                IcmpResult(true, null)
            } else {
                val out = p.inputStream.bufferedReader().readText()
                val m = timeRe.find(out)
                if (m != null) IcmpResult(true, m.groupValues[1].toDouble())
                else IcmpResult(out.contains("packets transmitted") || out.contains("icmp_seq"), null)
            }
        } catch (e: Exception) {
            icmpBroken = true
            IcmpResult(false, null)
        }
    }

    private fun tcp(host: String, timeoutMs: Int): Double? {
        val t0 = System.nanoTime()
        return try {
            Socket().use { it.connect(InetSocketAddress(host, 443), timeoutMs) }
            (System.nanoTime() - t0) / 1e6
        } catch (e: ConnectException) {
            if (e.message?.contains("refused", ignoreCase = true) == true) (System.nanoTime() - t0) / 1e6 else null
        } catch (e: Exception) { null }
    }

    /** Blocking single probe in ms, or null = no reply. */
    fun once(host: String, timeoutMs: Int = 2000): Double? {
        if (!icmpBroken) {
            val r = icmp(host, timeoutMs)
            if (r.rtt != null) { method = "ICMP"; return r.rtt }
            if (r.understood) { method = "ICMP"; return null }
        }
        method = "TCP:443"
        return tcp(host, timeoutMs)
    }

    /** One traceroute step using `ping -t TTL`. rtt is only known when the destination itself answered. */
    fun hop(host: String, ttl: Int): Hop {
        return try {
            val p = ProcessBuilder("/system/bin/ping", "-c", "1", "-t", ttl.toString(), "-W", "2", host)
                .redirectErrorStream(true).start()
            if (!p.waitFor(4000, TimeUnit.MILLISECONDS)) { p.destroyForcibly(); return Hop(ttl, null, null, false) }
            val out = p.inputStream.bufferedReader().readText()
            val tm = timeRe.find(out)
            if (tm != null) {
                val ip = Regex("from\\s+([0-9a-fA-F.:]+)").find(out)?.groupValues?.get(1)?.trimEnd(':')
                Hop(ttl, ip, tm.groupValues[1].toDouble(), true)
            } else {
                val ex = Regex("From\\s+([0-9a-fA-F.:]+)").find(out)
                Hop(ttl, ex?.groupValues?.get(1)?.trimEnd(':'), null, false)
            }
        } catch (e: Exception) { Hop(ttl, null, null, false) }
    }

    /**
     * Uncached DNS lookup time: a random label under a wildcard-DNS domain (nip.io, then sslip.io)
     * forces a real resolver round trip every time. Null = both failed.
     */
    fun dns(timeoutMs: Long = 2500): Double? {
        for (d in listOf("nip.io", "sslip.io")) {
            val name = "sc${Random.nextInt(1_000_000_000)}.1.1.1.1.$d"
            val t0 = System.nanoTime()
            val ok = timeboxed<Boolean>(timeoutMs) { try { InetAddress.getByName(name); true } catch (e: Exception) { null } }
            if (ok == true) return (System.nanoTime() - t0) / 1e6
        }
        return null
    }
}

fun chanOf(f: Int): Int = when {
    f in 2412..2472 -> (f - 2407) / 5
    f == 2484 -> 14
    f in 5000..5895 -> (f - 5000) / 5
    f in 5955..7115 -> (f - 5950) / 5
    else -> 0
}

fun bandOf(f: Int): String = if (f >= 5925) "6 GHz" else if (f >= 4900) "5 GHz" else "2.4 GHz"

data class WifiNow(val ssid: String, val bssid: String, val rssi: Int, val linkMbps: Int, val freqMhz: Int) {
    val channel: Int get() = chanOf(freqMhz)
    val band: String get() = bandOf(freqMhz)
}

data class ScanItem(val ssid: String, val bssid: String, val rssi: Int, val freqMhz: Int, val security: String) {
    val channel: Int get() = chanOf(freqMhz)
    val band: String get() = bandOf(freqMhz)
}

object WifiTool {
    @Suppress("DEPRECATION")
    fun now(ctx: Context): WifiNow? {
        return try {
            val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val i = wm.connectionInfo ?: return null
            if (i.rssi <= -127 || i.networkId == -1) return null
            var ssid = i.ssid?.trim('"') ?: ""
            if (ssid == "<unknown ssid>" || ssid.isBlank()) ssid = "(location permission needed)"
            WifiNow(ssid, i.bssid ?: "", i.rssi, i.linkSpeed, i.frequency)
        } catch (e: Exception) { null }
    }

    @Suppress("DEPRECATION")
    fun requestScan(ctx: Context): Boolean = try {
        (ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).startScan()
    } catch (e: Exception) { false }

    @Suppress("DEPRECATION")
    fun results(ctx: Context): List<ScanItem> = try {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        wm.scanResults.map {
            val c = it.capabilities ?: ""
            val sec = when {
                c.contains("SAE") -> "WPA3"
                c.contains("WPA2") || c.contains("RSN") -> "WPA2"
                c.contains("WPA") -> "WPA"
                c.contains("WEP") -> "WEP"
                else -> "Open"
            }
            ScanItem(if (it.SSID.isNullOrBlank()) "(hidden)" else it.SSID, it.BSSID ?: "", it.level, it.frequency, sec)
        }.sortedByDescending { it.rssi }
    } catch (e: Exception) { emptyList() }
}

object NetTools {
    fun hasLocation(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    @Suppress("DEPRECATION")
    fun gateway(ctx: Context): String? = try {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val g = wm.dhcpInfo?.gateway ?: 0
        if (g == 0) null else "${g and 0xff}.${(g shr 8) and 0xff}.${(g shr 16) and 0xff}.${(g shr 24) and 0xff}"
    } catch (e: Exception) { null }

    fun connType(ctx: Context): String {
        return try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val n = cm.activeNetwork ?: return "None"
            val c = cm.getNetworkCapabilities(n) ?: return "None"
            when {
                c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
                c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile data"
                c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
                c.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "VPN"
                else -> "Other"
            }
        } catch (e: Exception) { "Unknown" }
    }

    /** Blocking. Connection facts + gateway latency + uncached DNS time. */
    fun snapshot(ctx: Context): NetSnap {
        val type = connType(ctx)
        val w = WifiTool.now(ctx)
        val gw = gateway(ctx)
        val gms = if (gw != null) (PingTool.once(gw, 1500) ?: -1.0) else -1.0
        val dns = PingTool.dns(2000) ?: -1.0
        return NetSnap(type, w?.ssid ?: "", w?.rssi ?: 0, w?.linkMbps ?: 0, w?.freqMhz ?: 0, gw ?: "", gms, dns)
    }
}

data class LatState(
    val running: Boolean = false,
    val elapsed: Int = 0,
    val total: Int = 0,
    val series: Map<String, List<Double>> = emptyMap()   // -1 = no reply
)

/** In-app latency run (not a service): 1 s tick, gateway + targets + uncached DNS. */
class LatencyRunner(private val ctx: Context) {
    val state = MutableStateFlow(LatState())

    suspend fun run(targets: List<String>, durationSec: Int) {
        val gw = withContext(Dispatchers.IO) { NetTools.gateway(ctx) }
        val data = LinkedHashMap<String, ArrayList<Double>>()
        if (gw != null) data["Gateway"] = ArrayList()
        targets.forEach { data[it] = ArrayList() }
        data["DNS"] = ArrayList()
        state.value = LatState(true, 0, durationSec, data.mapValues { it.value.toList() })
        try {
            for (sec in 1..durationSec) {
                val t0 = SystemClock.elapsedRealtime()
                coroutineScope {
                    val jobs = ArrayList<Deferred<Pair<String, Double?>>>()
                    if (gw != null) jobs.add(async(Dispatchers.IO) { Pair("Gateway", PingTool.once(gw, 1500)) })
                    targets.forEach { tg -> jobs.add(async(Dispatchers.IO) { Pair(tg, PingTool.once(tg, 1500)) }) }
                    jobs.add(async(Dispatchers.IO) { Pair("DNS", PingTool.dns(2000)) })
                    for (r in jobs.awaitAll()) data[r.first]?.add(r.second ?: -1.0)
                }
                state.value = LatState(true, sec, durationSec, data.mapValues { it.value.toList() })
                delay(maxOf(0L, 1000 - (SystemClock.elapsedRealtime() - t0)))
            }
        } finally {
            state.update { it.copy(running = false) }
        }
    }
}

/** Latest results of the Tools screens, so exported reports can include them. */
object Extras {
    @Volatile var latency: List<String> = emptyList()
    @Volatile var signal: List<String> = emptyList()
    @Volatile var scan: List<ScanItem> = emptyList()

    fun lines(): List<String> {
        val out = ArrayList<String>()
        if (latency.isNotEmpty()) { out.add("Latency tool (last run):"); out.addAll(latency) }
        if (signal.isNotEmpty()) { out.add("Signal tool (last run):"); out.addAll(signal) }
        if (scan.isNotEmpty()) {
            out.add("Wi-Fi scan (last run, strongest 5):")
            scan.take(5).forEach { out.add("${it.ssid}  ${it.rssi} dBm  ch ${it.channel} (${it.band})  ${it.security}") }
        }
        return out
    }
}
