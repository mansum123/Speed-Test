package com.speedscope.app.engine

import com.speedscope.app.data.*
import kotlinx.coroutines.flow.MutableStateFlow

data class RunConfig(
    val kind: String,            // "speed" | "long" | "video"
    val mode: RunMode,
    val durSec: Int,             // primary duration (download / upload / both / sequential-download)
    val upSec: Int,              // sequential: upload duration
    val conn: ConnType,
    val server: Server
)

data class LiveState(
    val running: Boolean = false,
    val kind: String = "",
    val phaseIdx: Int = 0,
    val phaseCount: Int = 0,
    val phaseDir: Dir? = null,
    val elapsed: Int = 0,
    val total: Int = 0,
    val down: Double = 0.0,
    val up: Double = 0.0,
    val ping: Double = -1.0,
    val samples: List<Sample> = emptyList(),
    val status: String = "",
    val error: String? = null,
    val finishedId: String? = null
)

object TestState {
    @Volatile var pending: RunConfig? = null
    val live = MutableStateFlow(LiveState())
    val last = MutableStateFlow<Report?>(null)
}
