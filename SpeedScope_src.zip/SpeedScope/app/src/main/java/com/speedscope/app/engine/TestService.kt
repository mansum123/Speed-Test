package com.speedscope.app.engine

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.speedscope.app.data.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.update

class TestService : Service() {
    companion object {
        const val ACTION_START = "com.speedscope.app.START"
        const val ACTION_STOP = "com.speedscope.app.STOP"
        private const val NOTIF_ID = 11
        private const val DONE_ID = 12

        fun start(ctx: Context, cfg: RunConfig) {
            TestState.pending = cfg
            ContextCompat.startForegroundService(ctx, Intent(ctx, TestService::class.java).setAction(ACTION_START))
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, TestService::class.java).setAction(ACTION_STOP))
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null
    private var lastNotifyAt = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Notif.channels(this)
        when (intent?.action) {
            ACTION_START -> {
                // Must call startForeground right away after startForegroundService().
                startFg(baseNotif("SpeedScope", "Preparing…"))
                val cfg = TestState.pending
                if (cfg == null) { stopSelf(); return START_NOT_STICKY }
                if (job?.isActive != true) job = scope.launch { runTest(cfg) }
            }
            ACTION_STOP -> {
                val j = job
                if (j == null || !j.isActive) stopSelf() else j.cancel()
            }
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun stopIntent(): PendingIntent = PendingIntent.getService(
        this, 1, Intent(this, TestService::class.java).setAction(ACTION_STOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun baseNotif(title: String, text: String): Notification =
        Notif.builder(this, Notif.CH_RUN, title, text).setOngoing(true).addAction(0, "Stop", stopIntent()).build()

    private fun startFg(n: Notification) {
        try {
            ServiceCompat.startForeground(this, NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } catch (e: Exception) { /* FGS start not allowed right now; run anyway */ }
    }

    @Suppress("DEPRECATION")
    private fun acquireLocks(totalSec: Int) {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "speedscope:test").apply { acquire((totalSec + 180) * 1000L) }
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            wifi = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "speedscope:test").apply { acquire() }
        } catch (e: Exception) { /* best effort */ }
    }

    private fun releaseLocks() {
        try { wake?.takeIf { it.isHeld }?.release() } catch (e: Exception) { }
        try { wifi?.takeIf { it.isHeld }?.release() } catch (e: Exception) { }
        wake = null; wifi = null
    }

    private suspend fun runTest(cfg: RunConfig) {
        val appCtx = applicationContext
        val phases = Plans.build(cfg.mode, cfg.durSec, cfg.upSec)
        val total = Plans.totalSec(phases)
        val samples = ArrayList<Sample>()
        TestState.live.value = LiveState(running = true, kind = cfg.kind, total = total, phaseCount = phases.size, status = "Preparing…")
        acquireLocks(total)

        val startedAt = System.currentTimeMillis()
        var idle = -1.0
        var server = cfg.server
        var loc = cfg.server.loc
        var err: String? = null
        var cancelled = false
        var snap = NetSnap()
        try {
            snap = withContext(Dispatchers.IO) { NetTools.snapshot(appCtx) }
            if (server.kind == "auto") {
                TestState.live.update { it.copy(status = "Finding best server…") }
                server = withContext(Dispatchers.IO) { Servers.resolveAuto(appCtx) }
                loc = server.loc
            }
            val ep = Servers.resolve(server)
            if (server.kind == "cf") {
                val l = withContext(Dispatchers.IO) { Servers.cfLocation() }
                if (l != null) loc = l
            }
            TestState.live.update { it.copy(status = "Measuring latency…") }
            idle = SpeedEngine.idlePing(ep)
            SpeedEngine.run(cfg, ep) { s, idx, ph ->
                samples.add(s)
                TestState.live.value = LiveState(
                    running = true, kind = cfg.kind, phaseIdx = idx, phaseCount = phases.size, phaseDir = ph.dir,
                    elapsed = s.t, total = total, down = s.down, up = s.up, ping = s.ping, samples = samples.toList()
                )
                progressNotif(ph.dir, s, total)
            }
        } catch (e: CancellationException) {
            cancelled = true
        } catch (e: Exception) {
            err = e.message ?: e.javaClass.simpleName
        }

        var saved: Report? = null
        if (samples.size >= 3) {
            val partial = cancelled || err != null || samples.size < total
            val r = Report(startedAt.toString(), cfg.kind, startedAt, cfg.mode, cfg.conn, phases, server.name, loc, samples.toList(), idle, snap, partial)
            try { History.save(appCtx, r); saved = r } catch (e: Exception) { err = "Could not save report: ${e.message}"; saved = r }
        } else if (err == null) {
            err = "Stopped before enough data was collected"
        }
        if (saved != null) TestState.last.value = saved
        TestState.live.value = LiveState(running = false, kind = cfg.kind, error = err, finishedId = saved?.id)
        releaseLocks()
        doneNotif(saved, err)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun progressNotif(dir: Dir, s: Sample, total: Int) {
        val now = System.currentTimeMillis()
        if (now - lastNotifyAt < 2000) return
        lastNotifyAt = now
        val txt = when (dir) {
            Dir.DOWN -> "↓ ${f1(s.down)} Mbps"
            Dir.UP -> "↑ ${f1(s.up)} Mbps"
            Dir.BOTH -> "↓ ${f1(s.down)}  ↑ ${f1(s.up)} Mbps"
        } + "  ·  ${fmtClock(s.t)} / ${fmtClock(total)}"
        Notif.notify(this, NOTIF_ID, baseNotif("SpeedScope running", txt))
    }

    private fun doneNotif(r: Report?, err: String?) {
        val text = if (r != null) {
            val dn = steady(r.downValues()); val up = steady(r.upValues())
            val parts = ArrayList<String>()
            if (r.hasDown) parts.add("↓ ${f1(statsOf(dn).avg)} Mbps")
            if (r.hasUp) parts.add("↑ ${f1(statsOf(up).avg)} Mbps")
            parts.joinToString("  ") + if (r.partial) "  (partial)" else ""
        } else (err ?: "No result")
        val n = Notif.builder(this, Notif.CH_ALERT, if (r != null) "Test finished" else "Test failed", text).setAutoCancel(true).build()
        Notif.notify(this, DONE_ID, n)
    }

    override fun onDestroy() {
        scope.cancel()
        releaseLocks()
        super.onDestroy()
    }
}
