package com.speedscope.app.ui

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.speedscope.app.data.*
import com.speedscope.app.engine.Extras
import com.speedscope.app.engine.LatencyRunner
import com.speedscope.app.engine.NetTools
import com.speedscope.app.engine.RunConfig
import com.speedscope.app.engine.ScanItem
import com.speedscope.app.engine.TestService
import com.speedscope.app.engine.TestState
import com.speedscope.app.engine.WifiNow
import com.speedscope.app.engine.WifiTool
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val PALETTE = listOf(C.Teal, C.Purple, C.Orange, C.Green, C.Blue, C.Red)

/** Returns (granted, requestFn) for the location permission (needed for Wi-Fi name and scan results). */
@Composable
private fun rememberLocationGate(): Pair<Boolean, () -> Unit> {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(NetTools.hasLocation(ctx)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    return Pair(granted, { launcher.launch(Manifest.permission.ACCESS_FINE_LOCATION) })
}

@Composable
private fun ToolCard(title: String, text: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(C.Card).clickable { onClick() }.padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = C.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Gap(2.dp)
            Label(text)
        }
        Text("›", color = C.Muted, fontSize = 24.sp)
    }
}

@Composable
fun ToolsScreen(onOpen: (String) -> Unit, onHistory: () -> Unit, onServers: () -> Unit) {
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader("Tools", null)
        ToolCard("Latency", "Gateway, internet and DNS response time, second by second") { onOpen("latency") }
        ToolCard("Signal", "Live Wi-Fi signal strength, link speed, band and channel") { onOpen("signal") }
        ToolCard("Wi-Fi scan", "Nearby networks and which channels are crowded") { onOpen("scan") }
        ToolCard("Video check", "20 s download test and the best video quality it can hold") { onOpen("video") }
        Gap(4.dp)
        ToolCard("History", "Saved speed tests and monitor sessions") { onHistory() }
        ToolCard("Test server", "Cloudflare, Ookla search or your own server") { onServers() }
        Gap(24.dp)
    }
}

// ---------------------------------------------------------------- Latency

@Composable
fun LatencyScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val runner = remember { LatencyRunner(ctx) }
    val st by runner.state.collectAsState()
    var targets by remember { mutableStateOf("8.8.8.8, 1.1.1.1") }
    var dur by remember { mutableStateOf(30) }
    var job by remember { mutableStateOf<Job?>(null) }

    LaunchedEffect(st.running) {
        if (!st.running && st.series.isNotEmpty()) {
            Extras.latency = st.series.map { (name, v) ->
                val ok = v.filter { it >= 0 }
                val loss = if (v.isEmpty()) 0.0 else (v.size - ok.size) * 100.0 / v.size
                name + ": avg " + (if (ok.isEmpty()) "–" else fmtMs(ok.average())) +
                    ", max " + (if (ok.isEmpty()) "–" else fmtMs(ok.max())) + ", loss " + f1(loss) + "%"
            }
        }
    }

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader("Latency", onBack)
        Panel {
            OutlinedTextField(
                value = targets, onValueChange = { targets = it }, singleLine = true, enabled = !st.running,
                label = { Text("Targets (comma separated)") }, modifier = Modifier.fillMaxWidth()
            )
            Gap(10.dp)
            Label("Duration")
            Chips(listOf(10, 30, 60, 300), dur, { fmtDur(it) }, enabled = !st.running) { dur = it }
            Gap(12.dp)
            if (st.running) {
                Bar(if (st.total > 0) st.elapsed.toFloat() / st.total else 0f, C.Teal)
                Gap(4.dp)
                Label(fmtClock(st.elapsed) + " / " + fmtClock(st.total))
                Gap(8.dp)
                PrimaryButton("Stop", { job?.cancel() }, Modifier.fillMaxWidth(), color = C.Red)
            } else {
                PrimaryButton("Start", {
                    val list = targets.split(',', ' ', ';').map { it.trim() }.filter { it.isNotEmpty() }.distinct().take(4)
                    job = scope.launch { runner.run(list, dur) }
                }, Modifier.fillMaxWidth())
            }
        }
        if (st.series.isNotEmpty() && st.series.values.first().isNotEmpty()) {
            val names = st.series.keys.toList()
            ChartCard(
                "Response time", names.mapIndexed { i, n -> Line(st.series[n] ?: emptyList(), PALETTE[i % PALETTE.size]) },
                names.mapIndexed { i, n -> n to PALETTE[i % PALETTE.size] }, "ms"
            )
            Panel {
                Title("Summary")
                Gap(8.dp)
                for (n in names) {
                    val v = st.series[n] ?: emptyList()
                    val ok = v.filter { it >= 0 }
                    val loss = if (v.isEmpty()) 0.0 else (v.size - ok.size) * 100.0 / v.size
                    Text(n, color = C.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Label(
                        if (ok.isEmpty()) "no reply  ·  loss 100%"
                        else "avg " + fmtMs(ok.average()) + "  ·  min " + fmtMs(ok.min()) + "  ·  max " + fmtMs(ok.max()) +
                            "  ·  jitter " + fmtMs(jitter(v)) + "  ·  loss " + f1(loss) + "%"
                    )
                    Gap(8.dp)
                }
                Label("Gateway = your router. DNS = uncached lookup time. Results are included in exported speed reports.")
            }
        }
        Gap(24.dp)
    }
}

// ---------------------------------------------------------------- Signal

private fun signalQuality(rssi: Int): Pair<String, Color> = when {
    rssi >= -50 -> "Excellent" to C.Green
    rssi >= -60 -> "Good" to C.Green
    rssi >= -70 -> "Fair" to C.Orange
    rssi >= -80 -> "Weak" to C.Orange
    else -> "Very weak" to C.Red
}

@Composable
fun SignalScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val (hasLoc, askLoc) = rememberLocationGate()
    var now by remember { mutableStateOf<WifiNow?>(null) }
    var hist by remember { mutableStateOf<List<Double>>(emptyList()) }

    LaunchedEffect(Unit) {
        while (true) {
            val w = withContext(Dispatchers.IO) { WifiTool.now(ctx) }
            now = w
            if (w != null) {
                hist = (hist + w.rssi.toDouble()).takeLast(300)
                val v = hist
                Extras.signal = listOf(
                    (if (w.ssid.isNotBlank()) w.ssid + "  " else "") + w.band + " ch " + w.channel + "  link " + w.linkMbps + " Mbps",
                    "RSSI now " + w.rssi + " dBm, avg " + f0(v.average()) + ", min " + f0(v.min()) + ", max " + f0(v.max())
                )
            }
            delay(1000)
        }
    }

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader("Signal", onBack)
        if (!hasLoc) {
            Notice("Android hides the Wi-Fi name until location permission is granted.")
            SoftButton("Grant location permission", askLoc)
        }
        val w = now
        if (w == null) {
            Panel { Body("Not connected to Wi-Fi (signal tool works on Wi-Fi only).", color = C.Muted) }
        } else {
            val q = signalQuality(w.rssi)
            Panel {
                Label(w.ssid.ifBlank { "Wi-Fi" })
                Text("${w.rssi} dBm", color = q.second, fontSize = 40.sp, fontWeight = FontWeight.Bold)
                Text(q.first, color = q.second, fontSize = 16.sp)
                Gap(12.dp)
                StatGrid(listOf(
                    "Link speed" to (if (w.linkMbps > 0) "${w.linkMbps} Mbps" else "–"),
                    "Band" to w.band,
                    "Channel" to w.channel.toString()
                ))
            }
            if (hist.size >= 2) {
                // dBm + 100 so that a taller line = a stronger signal
                ChartCard(
                    "Signal level (dBm + 100, higher is better)",
                    listOf(Line(hist.map { (it + 100.0).coerceAtLeast(0.0) }, C.Teal)),
                    listOf("Signal" to C.Teal), "", yMax = 70.0
                )
                Panel {
                    Title("Last ${hist.size} s")
                    Gap(8.dp)
                    StatGrid(listOf(
                        "Average" to f0(hist.average()) + " dBm", "Weakest" to f0(hist.min()) + " dBm", "Strongest" to f0(hist.max()) + " dBm"
                    ))
                }
            }
        }
        Gap(24.dp)
    }
}

// ---------------------------------------------------------------- Wi-Fi scan

@Composable
fun ScanScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val (hasLoc, askLoc) = rememberLocationGate()
    var items by remember { mutableStateOf<List<ScanItem>>(emptyList()) }
    var scanning by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf<String?>(null) }

    fun load() {
        scope.launch {
            val r = withContext(Dispatchers.IO) { WifiTool.results(ctx) }
            items = r
            Extras.scan = r
        }
    }

    fun scan() {
        scope.launch {
            scanning = true; note = null
            val started = withContext(Dispatchers.IO) { WifiTool.requestScan(ctx) }
            if (!started) note = "Android limited the scan rate (a few scans per 2 minutes). Showing the latest results."
            delay(3000)
            load()
            scanning = false
        }
    }

    LaunchedEffect(hasLoc) { if (hasLoc) load() }

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader("Wi-Fi scan", onBack)
        if (!hasLoc) {
            Notice("Android needs location permission to list nearby Wi-Fi networks.")
            PrimaryButton("Grant location permission", askLoc, Modifier.fillMaxWidth())
        } else {
            PrimaryButton(if (scanning) "Scanning…" else "Scan now", { scan() }, Modifier.fillMaxWidth(), enabled = !scanning)
            val n = note
            if (n != null) Notice(n)
        }
        if (items.isNotEmpty()) {
            val crowd = items.groupBy { it.band to it.channel }.entries.sortedByDescending { it.value.size }.take(6)
            Panel {
                Title("Channel usage")
                Gap(6.dp)
                for (e in crowd) {
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                        Text(e.key.first + "  ch " + e.key.second, color = C.Text, fontSize = 13.sp, modifier = Modifier.weight(1f))
                        Text(e.value.size.toString() + " network(s)", color = if (e.value.size >= 4) C.Orange else C.Muted, fontSize = 13.sp)
                    }
                }
                Gap(6.dp)
                Label("Many networks on the same channel can slow each other down. Try a less crowded channel or the 5 GHz band.")
            }
            Panel {
                Title("Networks (${items.size})")
                Gap(8.dp)
                for (ap in items) {
                    val q = signalQuality(ap.rssi)
                    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(ap.ssid, color = C.Text, fontSize = 14.sp, maxLines = 1)
                            Label(ap.band + "  ch " + ap.channel + "  ·  " + ap.security)
                        }
                        Text("${ap.rssi} dBm", color = q.second, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        } else if (hasLoc && !scanning) {
            Panel { Body("No results yet. Tap \"Scan now\" (Wi-Fi and location must be on).", color = C.Muted) }
        }
        Gap(24.dp)
    }
}

// ---------------------------------------------------------------- Video check

@Composable
fun VideoScreen(ui: UiPrefs, onBack: () -> Unit, onOpenReport: (String) -> Unit) {
    val ctx = LocalContext.current
    val live by TestState.live.collectAsState()
    val mine = live.running && live.kind == "video"
    val busyOther = live.running && live.kind != "video"
    val rep = rememberLatest("video")

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader("Video check", onBack)
        Panel {
            Body("Downloads for 20 seconds and checks which video qualities your connection can hold without buffering. The slowest 10% of seconds decide the result, not the average.", color = C.Muted)
        }
        if (mine) {
            LiveRun(live, ui)
            PrimaryButton("Stop", { TestService.stop(ctx) }, Modifier.fillMaxWidth(), color = C.Red)
        } else {
            val err = live.error
            if (err != null) Notice(err, C.Red)
            if (busyOther) Notice("A ${kindLabel(live.kind)} is running. Wait for it to finish first.")
            PrimaryButton(
                "Start video check (20 s)",
                { TestService.start(ctx, RunConfig("video", RunMode.DOWNLOAD, 20, 0, ui.conn, ui.server)) },
                Modifier.fillMaxWidth(), enabled = !busyOther
            )
            if (rep != null) {
                VideoPanel(rep.downValues())
                SoftButton("Full report & export", { onOpenReport(rep.id) }, Modifier.fillMaxWidth())
            }
        }
        Gap(24.dp)
    }
}
