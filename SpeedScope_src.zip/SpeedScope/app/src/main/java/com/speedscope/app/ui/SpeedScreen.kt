package com.speedscope.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.speedscope.app.data.*
import com.speedscope.app.engine.LiveState
import com.speedscope.app.engine.RunConfig
import com.speedscope.app.engine.TestService
import com.speedscope.app.engine.TestState

/** Timeline of a finished report: values outside a series' own phase become gaps (-1). */
fun timelineLines(r: Report, unit: SpeedUnit): List<Line> {
    val down = r.samples.map { if (r.dirAt(it.t) == Dir.UP) -1.0 else it.down * unit.perMbps }
    val up = r.samples.map { if (r.dirAt(it.t) == Dir.DOWN) -1.0 else it.up * unit.perMbps }
    val out = ArrayList<Line>()
    if (r.hasDown) out.add(Line(down, C.Green))
    if (r.hasUp) out.add(Line(up, C.Orange))
    return out
}

fun phaseName(d: Dir?): String = when (d) {
    Dir.DOWN -> "Download"
    Dir.UP -> "Upload"
    Dir.BOTH -> "Download + Upload"
    null -> "Preparing"
}

/** Gauge + live numbers + progress for a running test (shared by Speed and Long Run). */
@Composable
fun LiveRun(live: LiveState, ui: UiPrefs) {
    val unit = ui.unit
    val dir = live.phaseDir ?: Dir.DOWN
    val cur = if (dir == Dir.UP) live.up else live.down
    val color = if (dir == Dir.UP) C.Orange else C.Green
    var peak = 0.0
    for (s in live.samples) {
        val v = if (dir == Dir.UP) s.up else s.down
        if (v > peak) peak = v
    }
    val maxM = if (ui.scale == GaugeScale.AUTO) niceMax(maxOf(cur, peak)) else ui.scale.max
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Gauge(
            frac = (cur / maxM).toFloat(),
            big = if (live.phaseDir == null) "…" else fmtSpeed(cur, unit),
            unit = unit.label, color = C.Blue, color2 = color,
            caption = if (live.phaseDir == null) live.status else phaseName(live.phaseDir)
        )
    }
    Gap(6.dp)
    Panel {
        Row(Modifier.fillMaxWidth()) {
            LiveTile("Download", if (live.phaseDir == null || live.phaseDir == Dir.UP && live.down <= 0.0) "–" else fmtSpeed(live.down, unit), C.Green, Modifier.weight(1f))
            LiveTile("Upload", if (live.phaseDir == Dir.DOWN || live.phaseDir == null) "–" else fmtSpeed(live.up, unit), C.Orange, Modifier.weight(1f))
            LiveTile("Ping", if (live.ping < 0) "–" else fmtMs(live.ping), C.Purple, Modifier.weight(1f))
        }
        Gap(12.dp)
        Bar(if (live.total > 0) live.elapsed.toFloat() / live.total else 0f, color)
        Gap(6.dp)
        Row(Modifier.fillMaxWidth()) {
            Label(
                (if (live.phaseCount > 1) "Phase ${live.phaseIdx + 1}/${live.phaseCount}  ·  " else "") + phaseName(live.phaseDir),
                Modifier.weight(1f)
            )
            Label(fmtClock(live.elapsed) + " / " + fmtClock(live.total))
        }
    }
    if (live.samples.size >= 2) {
        Gap(12.dp)
        ChartCard(
            "Live speed",
            listOf(
                Line(live.samples.map { if (it.down <= 0.0) -1.0 else it.down * unit.perMbps }, C.Green),
                Line(live.samples.map { if (it.up <= 0.0) -1.0 else it.up * unit.perMbps }, C.Orange)
            ),
            listOf("Download" to C.Green, "Upload" to C.Orange), unit.label
        )
    }
}

@Composable
private fun LiveTile(label: String, value: String, color: androidx.compose.ui.graphics.Color, modifier: Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Label(label)
        Text(value, color = color, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun BigTile(label: String, value: String, unit: String, color: androidx.compose.ui.graphics.Color, modifier: Modifier) {
    Column(
        modifier.clip(androidx.compose.foundation.shape.RoundedCornerShape(16.dp)).background(color.copy(alpha = 0.10f)).padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(label, color = color, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        Text(value, color = color, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Label(unit)
    }
}

/** Compact summary of the last finished run with a link to the full report. */
@Composable
fun ResultCard(r: Report, unit: SpeedUnit, onOpen: (String) -> Unit) {
    val pv = r.pings()
    val dn = statsOf(steady(r.downValues()))
    val up = statsOf(steady(r.upValues()))
    Panel {
        Title("Last result")
        Label(fmtTime(r.startedAt) + "  ·  " + r.server)
        Gap(10.dp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            BigTile("Download", if (r.hasDown) fmtSpeed(dn.avg, unit) else "–", unit.label, C.Green, Modifier.weight(1f))
            BigTile("Upload", if (r.hasUp) fmtSpeed(up.avg, unit) else "–", unit.label, C.Orange, Modifier.weight(1f))
        }
        Gap(12.dp)
        StatGrid(listOf(
            "Idle ping" to fmtMs(r.idlePingMs),
            "Ping under load" to (if (pv.isEmpty()) "–" else fmtMs(pv.average())),
            "Jitter" to (if (pv.size < 2) "–" else fmtMs(jitter(pv))),
            "Measured" to fmtDur(r.samples.size)
        ))
        if (r.partial) { Gap(10.dp); Notice("Partial result (stopped early or error).") }
    }
    Gap(12.dp)
    ChartCard("Speed over time", timelineLines(r, unit), listOf("Download" to C.Green, "Upload" to C.Orange), unit.label)
    Gap(12.dp)
    PrimaryButton("Details & export (PDF / PNG)", { onOpen(r.id) }, Modifier.fillMaxWidth())
}

@Composable
fun SpeedScreen(ui: UiPrefs, onServers: () -> Unit, onOpenReport: (String) -> Unit) {
    val ctx = LocalContext.current
    val live by TestState.live.collectAsState()
    val mine = live.running && live.kind == "speed"
    val busyOther = live.running && live.kind != "speed"
    val rep = rememberLatest("speed")

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp)) {
        ScreenHeader("Speed Test", null)
        ServerCard(ui.server.name, ui.server.loc, onServers)
        Gap(10.dp)
        if (mine) {
            LiveRun(live, ui)
        } else {
            val shownDn = rep?.let { statsOf(steady(it.downValues())).avg }
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Gauge(
                    frac = 0f,
                    big = if (rep != null && shownDn != null && rep.hasDown) fmtSpeed(shownDn, ui.unit) else "–",
                    unit = ui.unit.label, color = C.Blue, color2 = C.Green,
                    caption = if (rep != null) "Last download" else "Ready"
                )
            }
        }
        Gap(14.dp)
        if (busyOther) {
            Notice("A ${kindLabel(live.kind)} is running. Stop it from the Long Run tab before starting a Speed Test.")
            Gap(10.dp)
        }
        val err = live.error
        if (!mine && err != null) { Notice(err, C.Red); Gap(10.dp) }

        if (mine) {
            PrimaryButton("Stop", { TestService.stop(ctx) }, Modifier.fillMaxWidth(), color = C.Red)
        } else {
            PrimaryButton(
                "Start speed test (10 s down + 10 s up)",
                { TestService.start(ctx, RunConfig("speed", RunMode.SEQUENTIAL, 10, 10, ui.conn, ui.server)) },
                Modifier.fillMaxWidth(), enabled = !busyOther
            )
        }
        Gap(14.dp)

        Panel {
            Title("Settings")
            Gap(10.dp)
            Label("Unit")
            Segmented(SpeedUnit.values().toList(), ui.unit, { it.label }) { ui.updateUnit(it) }
            Gap(10.dp)
            Label("Gauge scale (Mbps)")
            Segmented(GaugeScale.values().toList(), ui.scale, { it.label }) { ui.updateScale(it) }
            Gap(10.dp)
            Label("Connections (download / upload)")
            Segmented(ConnType.values().toList(), ui.conn, { it.label }, enabled = !mine) { ui.updateConn(it) }
        }
        if (!mine && rep != null) {
            Gap(14.dp)
            ResultCard(rep, ui.unit, onOpenReport)
        }
        Gap(24.dp)
    }
}
