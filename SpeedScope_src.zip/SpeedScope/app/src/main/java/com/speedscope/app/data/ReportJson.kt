package com.speedscope.app.data

import org.json.JSONArray
import org.json.JSONObject

inline fun <reified T : Enum<T>> enumOr(s: String?, d: T): T =
    try { enumValueOf<T>(s ?: "") } catch (e: Exception) { d }

private fun fin(x: Double): Double = if (x.isNaN() || x.isInfinite()) 0.0 else Math.round(x * 100.0) / 100.0

object ReportJson {
    fun toJson(r: Report): JSONObject {
        val o = JSONObject()
        o.put("id", r.id); o.put("kind", r.kind); o.put("startedAt", r.startedAt)
        o.put("mode", r.mode.name); o.put("conn", r.conn.name)
        val ph = JSONArray()
        r.phases.forEach { ph.put(JSONArray().put(it.dir.name).put(it.seconds)) }
        o.put("phases", ph)
        o.put("server", r.server); o.put("serverLoc", r.serverLoc)
        o.put("idlePing", fin(r.idlePingMs)); o.put("partial", r.partial)
        val s = r.snap
        o.put("snap", JSONObject().put("type", s.type).put("ssid", s.ssid).put("rssi", s.rssi)
            .put("link", s.linkMbps).put("freq", s.freqMhz).put("gw", s.gateway)
            .put("gwMs", fin(s.gatewayMs)).put("dnsMs", fin(s.dnsMs)))
        val sa = JSONArray()
        r.samples.forEach { sa.put(JSONArray().put(it.t).put(fin(it.down)).put(fin(it.up)).put(fin(it.ping))) }
        o.put("samples", sa)
        return o
    }

    fun fromJson(o: JSONObject): Report {
        val ph = ArrayList<Phase>()
        val pa = o.optJSONArray("phases") ?: JSONArray()
        for (i in 0 until pa.length()) {
            val p = pa.getJSONArray(i)
            ph.add(Phase(enumOr(p.getString(0), Dir.DOWN), p.getInt(1)))
        }
        val sn = o.optJSONObject("snap") ?: JSONObject()
        val snap = NetSnap(
            sn.optString("type"), sn.optString("ssid"), sn.optInt("rssi"), sn.optInt("link"),
            sn.optInt("freq"), sn.optString("gw"), sn.optDouble("gwMs", -1.0), sn.optDouble("dnsMs", -1.0)
        )
        val samples = ArrayList<Sample>()
        val sa = o.optJSONArray("samples") ?: JSONArray()
        for (i in 0 until sa.length()) {
            val a = sa.getJSONArray(i)
            samples.add(Sample(a.getInt(0), a.getDouble(1), a.getDouble(2), a.getDouble(3)))
        }
        return Report(
            o.getString("id"), o.optString("kind", "speed"), o.optLong("startedAt"),
            enumOr(o.optString("mode"), RunMode.SEQUENTIAL), enumOr(o.optString("conn"), ConnType.MULTI),
            ph, o.optString("server"), o.optString("serverLoc"), samples,
            o.optDouble("idlePing", -1.0), snap, o.optBoolean("partial")
        )
    }
}
