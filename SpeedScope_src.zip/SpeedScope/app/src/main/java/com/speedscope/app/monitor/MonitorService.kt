package com.speedscope.app.monitor

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.speedscope.app.data.fmtDur
import com.speedscope.app.data.f1
import com.speedscope.app.data.fmtMs
import com.speedscope.app.engine.NetTools
import com.speedscope.app.engine.Notif
import com.speedscope.app.engine.PingTool
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class MonLive(
    val running: Boolean = false,
    val paused: Boolean = false,
    val sessionId: Long = 0,
    val target: String = "",
    val total: Int = 0,
    val ok: Int = 0,
    val dropped: Int = 0,
    val last: Double = -1.0,
    val outage: Boolean = false,
    val incidents: Int = 0,
    val recent: List<Double> = emptyList(),
    val startedAt: Long = 0,
    val method: String = ""
) {
    val availability: Double get() = if (total == 0) 100.0 else ok * 100.0 / total
}

object MonitorState {
    val live = MutableStateFlow(MonLive())
}

/** Compares gateway / internet / DNS and walks a TTL ladder. Wording stays honest: "no reply" is not proof of a fault. */
object HopAnalyzer {
    suspend fun diagnose(ctx: Context, target: String): String = withContext(Dispatchers.IO) {
        val type = NetTools.connType(ctx)
        val gw = NetTools.gateway(ctx)
        val gwMs = if (gw != null) PingTool.once(gw, 1500) else null
        val inet = PingTool.once("1.1.1.1", 1500) ?: PingTool.once("8.8.8.8", 1500)
        val dns = PingTool.dns(2000)
        val sb = StringBuilder()
        sb.append("Checked at ").append(SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())).append('\n')
        sb.append("Network: ").append(type).append('\n')
        if (gw != null) sb.append("Gateway ").append(gw).append(": ").append(if (gwMs != null) fmtMs(gwMs) else "no reply").append('\n')
        sb.append("Internet (1.1.1.1 / 8.8.8.8): ").append(if (inet != null) fmtMs(inet) else "no reply").append('\n')
        sb.append("DNS lookup: ").append(if (dns != null) fmtMs(dns) else "failed").append('\n')
        val verdict = when {
            type == "None" -> "No active network connection (Wi-Fi / mobile data off or disconnected)."
            gw != null && gwMs == null -> "Local link problem: the router/gateway did not answer (Wi-Fi signal or router)."
            inet == null && dns == null -> "Local link looks fine but the internet is unreachable - consistent with an ISP / upstream outage."
            inet == null && dns != null -> "DNS works but ICMP to public DNS is unanswered - ICMP may be filtered; check the target itself."
            inet != null && dns == null -> "Internet reachable but DNS failed - resolver / DNS problem."
            else -> "Everything is reachable now - the outage was brief or specific to the monitored target ($target)."
        }
        sb.append("Indicative result: ").append(verdict).append('\n')
        sb.append("Path to ").append(target).append(" (TTL ladder; 'no reply' only means that hop did not answer ICMP, not that it is faulty):\n")
        for (ttl in 1..8) {
            val h = PingTool.hop(target, ttl)
            sb.append(' ').append(ttl).append("  ")
                .append(if (h.ip != null) h.ip else "no reply")
                .append(if (h.reached) "  (destination, ${fmtMs(h.rttMs ?: -1.0)})" else "").append('\n')
            if (h.reached) break
        }
        sb.toString().trim()
    }
}

class MonitorService : Service() {
    companion object {
        const val ACTION_START = "com.speedscope.app.MON_START"
        const val ACTION_STOP = "com.speedscope.app.MON_STOP"
        const val ACTION_PAUSE = "com.speedscope.app.MON_PAUSE"
        const val ACTION_RESUME = "com.speedscope.app.MON_RESUME"
        private const val EXTRA_TARGET = "target"
        private const val EXTRA_INTERVAL = "interval"
        private const val NOTIF_ID = 21
        private const val ALERT_ID = 22

        fun start(ctx: Context, target: String, intervalSec: Int) {
            val i = Intent(ctx, MonitorService::class.java).setAction(ACTION_START)
                .putExtra(EXTRA_TARGET, target).putExtra(EXTRA_INTERVAL, intervalSec)
            ContextCompat.startForegroundService(ctx, i)
        }

        fun send(ctx: Context, action: String) {
            ctx.startService(Intent(ctx, MonitorService::class.java).setAction(action))
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    @Volatile private var paused = false
    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Notif.channels(this)
        when (intent?.action) {
            ACTION_START -> {
                val target = intent.getStringExtra(EXTRA_TARGET) ?: "8.8.8.8"
                val interval = intent.getIntExtra(EXTRA_INTERVAL, 2).coerceIn(1, 60)
                startFg(notif("Monitoring $target", "Starting…", false))
                if (job?.isActive != true) {
                    paused = false
                    job = scope.launch { loop(target, interval * 1000L) }
                }
            }
            ACTION_PAUSE -> { paused = true; MonitorState.live.update { it.copy(paused = true) } }
            ACTION_RESUME -> { paused = false; MonitorState.live.update { it.copy(paused = false) } }
            ACTION_STOP -> { val j = job; if (j == null || !j.isActive) stopSelf() else j.cancel() }
            else -> if (job?.isActive != true) stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun pi(act: String, code: Int): PendingIntent = PendingIntent.getService(
        this, code, Intent(this, MonitorService::class.java).setAction(act),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun notif(title: String, text: String, isPaused: Boolean): Notification {
        val b = Notif.builder(this, Notif.CH_RUN, title, text).setOngoing(true)
        if (isPaused) b.addAction(0, "Resume", pi(ACTION_RESUME, 2)) else b.addAction(0, "Pause", pi(ACTION_PAUSE, 3))
        b.addAction(0, "Stop", pi(ACTION_STOP, 4))
        return b.build()
    }

    private fun startFg(n: Notification) {
        try {
            val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            else ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            ServiceCompat.startForeground(this, NOTIF_ID, n, type)
        } catch (e: Exception) { /* run anyway */ }
    }

    @Suppress("DEPRECATION")
    private fun acquireLocks() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "speedscope:monitor").apply { acquire(24 * 3600 * 1000L) }
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            wifi = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "speedscope:monitor").apply { acquire() }
        } catch (e: Exception) { }
    }

    private fun releaseLocks() {
        try { wake?.takeIf { it.isHeld }?.release() } catch (e: Exception) { }
        try { wifi?.takeIf { it.isHeld }?.release() } catch (e: Exception) { }
        wake = null; wifi = null
    }

    private fun flushBlocking(db: MonitorDb, sid: Long, det: IncidentDetector, buf: ArrayList<Probe>, endedAt: Long = 0L) {
        try {
            db.insertProbes(sid, buf)
            buf.clear()
            db.saveIncidents(sid, det.incidents)
            db.updateSession(sid, det.total, det.ok, det.droppedProbes, PingTool.method, endedAt)
        } catch (e: Exception) { /* keep running; next flush retries incidents/session */ }
    }

    private suspend fun loop(target: String, intervalMs: Long) {
        val ctx = applicationContext
        val db = MonitorDb.get(ctx)
        val det = IncidentDetector(3)
        val buf = ArrayList<Probe>()
        val recent = ArrayDeque<Double>()
        val startedAt = System.currentTimeMillis()
        val sid = withContext(Dispatchers.IO) { db.startSession(target, intervalMs) }
        acquireLocks()
        MonitorState.live.value = MonLive(running = true, sessionId = sid, target = target, startedAt = startedAt)
        var lastFlush = SystemClock.elapsedRealtime()
        var lastNotif = 0L
        var wasPaused = false
        try {
            while (true) {
                if (paused) {
                    if (!wasPaused) {
                        wasPaused = true
                        det.interrupt()
                        withContext(Dispatchers.IO) { flushBlocking(db, sid, det, buf) }
                        Notif.notify(ctx, NOTIF_ID, notif("Monitoring paused", target, true))
                    }
                    delay(400)
                    continue
                }
                wasPaused = false
                val t0 = SystemClock.elapsedRealtime()
                val host = if (target == "gateway") NetTools.gateway(ctx) else target
                val rtt = if (host == null) null else withContext(Dispatchers.IO) { PingTool.once(host, 2000) }
                val now = System.currentTimeMillis()
                buf.add(Probe(now, rtt ?: -1.0))
                val ev = det.onProbe(now, rtt)
                recent.addLast(rtt ?: -1.0)
                if (recent.size > 120) recent.removeFirst()
                if (ev != null) onEvent(ev, target, host ?: target)
                MonitorState.live.value = MonLive(
                    running = true, paused = false, sessionId = sid, target = target, total = det.total, ok = det.ok,
                    dropped = det.droppedProbes, last = rtt ?: -1.0, outage = det.isOutage,
                    incidents = det.incidents.size, recent = recent.toList(), startedAt = startedAt, method = PingTool.method
                )
                if (t0 - lastFlush >= 10_000) {
                    withContext(Dispatchers.IO) { flushBlocking(db, sid, det, buf) }
                    lastFlush = t0
                }
                if (t0 - lastNotif >= 5_000) {
                    lastNotif = t0
                    val txt = f1(det.availability) + "% up  ·  " + (if (rtt != null) fmtMs(rtt) else "no reply") +
                        "  ·  " + det.incidents.size + " outage(s)"
                    Notif.notify(ctx, NOTIF_ID, notif("Monitoring $target", txt, false))
                }
                delay(maxOf(200L, intervalMs - (SystemClock.elapsedRealtime() - t0)))
            }
        } catch (e: CancellationException) {
            // stop requested
        }
        // Finalise with blocking calls only (the coroutine is already cancelled here).
        det.interrupt()
        flushBlocking(db, sid, det, buf, System.currentTimeMillis())
        MonitorState.live.value = MonitorState.live.value.copy(running = false, paused = false, outage = false)
        releaseLocks()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun onEvent(ev: DetEvent, target: String, host: String) {
        val ctx = applicationContext
        if (ev.type == EvType.STARTED) {
            Notif.notify(ctx, ALERT_ID, Notif.builder(ctx, Notif.CH_ALERT, "Connection lost", "$target is not answering (3+ probes failed)").setAutoCancel(true).build())
            scope.launch { ev.incident.diag = HopAnalyzer.diagnose(ctx, host) }
        } else {
            val secs = (((ev.incident.endMs ?: 0L) - ev.incident.startMs) / 1000).toInt().coerceAtLeast(0)
            Notif.notify(ctx, ALERT_ID, Notif.builder(ctx, Notif.CH_ALERT, "Back online", "$target recovered after ${fmtDur(secs)}").setAutoCancel(true).build())
        }
    }

    override fun onDestroy() {
        scope.cancel()
        releaseLocks()
        super.onDestroy()
    }
}
