package com.speedscope.app.engine

import org.json.JSONArray
import org.json.JSONObject
import okhttp3.Request
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

data class Server(
    val id: String, val name: String, val kind: String,   // kind: cf | ookla | custom
    val loc: String = "", val down: String = "", val up: String = "", val ping: String = "",
    val lat: Double = 0.0, val lon: Double = 0.0
)

data class Endpoints(val down: String, val up: String, val ping: String)

object Servers {
    val CF = Server("cf", "Cloudflare", "cf", "Nearest Cloudflare edge")
    /** Optional: picks the best Ookla server near the device (by location + latency) at test start. */
    val AUTO = Server("auto", "Auto (nearest)", "auto", "Best server near your location")

    @Volatile private var autoCache: Pair<Long, Server>? = null

    /** Blocking. Nearest few Ookla servers, lowest latency wins; falls back to Cloudflare. Cached 10 min. */
    fun resolveAuto(ctx: android.content.Context): Server {
        autoCache?.let { if (System.currentTimeMillis() - it.first < 600_000) return it.second }
        val picked = try {
            val loc = Loc.lastKnown(ctx)
            val list = ookla(null, loc?.first, loc?.second, 6)
            var best: Server? = null
            var bestMs = Double.MAX_VALUE
            for (s in list) {
                val ms = SpeedEngine.httpPing(s.ping) ?: continue
                if (ms < bestMs) { bestMs = ms; best = s }
            }
            best
        } catch (e: Exception) { null }
        val s = picked ?: CF
        if (picked != null) autoCache = Pair(System.currentTimeMillis(), s)
        return s
    }

    fun resolve(s: Server): Endpoints = when (s.kind) {
        "cf" -> Endpoints(
            "https://speed.cloudflare.com/__down?bytes=25000000",
            "https://speed.cloudflare.com/__up",
            "https://speed.cloudflare.com/__down?bytes=0"
        )
        else -> Endpoints(s.down, s.up.ifBlank { s.down }, s.ping.ifBlank { s.down })
    }

    fun bust(url: String): String = url + (if (url.contains('?')) "&" else "?") + "r=" + System.nanoTime()

    /** Blocking. Returns e.g. "Mumbai, IN (BOM)" or null. */
    fun cfLocation(): String? = try {
        val req = Request.Builder().url("https://speed.cloudflare.com/meta").build()
        Http.api.newCall(req).execute().use { r ->
            val j = JSONObject(r.body?.string() ?: "")
            val city = j.optString("city")
            val country = j.optString("country")
            val colo = j.optJSONObject("colo")?.optString("iata") ?: j.optString("colo")
            listOf(city, country).filter { it.isNotBlank() }.joinToString(", ") +
                (if (colo.isNotBlank()) " ($colo)" else "")
        }.ifBlank { null }
    } catch (e: Exception) { null }

    /** Blocking Ookla server search. lat/lon optional (used for "near me" ordering). */
    fun ookla(query: String?, lat: Double? = null, lon: Double? = null, limit: Int = 40): List<Server> {
        var url = "https://www.speedtest.net/api/js/servers?engine=js&https_functional=true&limit=$limit"
        if (!query.isNullOrBlank()) url += "&search=" + java.net.URLEncoder.encode(query.trim(), "UTF-8")
        if (lat != null && lon != null) url += "&lat=$lat&lon=$lon"
        val req = Request.Builder().url(url).header("Accept", "application/json").build()
        val body = Http.api.newCall(req).execute().use {
            if (!it.isSuccessful) throw java.io.IOException("Ookla server list returned HTTP ${it.code} (blocked on this network?)")
            it.body?.string() ?: "[]"
        }
        val arr = try { JSONArray(body) } catch (e: Exception) {
            throw java.io.IOException("Ookla server list unavailable (unexpected reply: " + body.take(60) + ")")
        }
        val out = ArrayList<Server>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val upUrl = o.optString("url")
            if (upUrl.isBlank()) continue
            val base = upUrl.substringBeforeLast('/')
            out.add(Server(
                "ookla:" + o.optString("id"), o.optString("sponsor").ifBlank { o.optString("name") }, "ookla",
                listOf(o.optString("name"), o.optString("country")).filter { it.isNotBlank() }.joinToString(", "),
                "$base/random4000x4000.jpg", upUrl, "$base/latency.txt",
                o.optDouble("lat", 0.0), o.optDouble("lon", 0.0)
            ))
        }
        return if (lat != null && lon != null) out.sortedBy { haversineKm(lat, lon, it.lat, it.lon) } else out
    }

    fun haversineKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2).pow(2) + cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2).pow(2)
        return 2 * r * asin(sqrt(a))
    }

    fun toJson(s: Server): JSONObject = JSONObject().put("id", s.id).put("name", s.name).put("kind", s.kind)
        .put("loc", s.loc).put("down", s.down).put("up", s.up).put("ping", s.ping).put("lat", s.lat).put("lon", s.lon)

    fun fromJson(o: JSONObject): Server = Server(
        o.getString("id"), o.getString("name"), o.getString("kind"), o.optString("loc"),
        o.optString("down"), o.optString("up"), o.optString("ping"), o.optDouble("lat", 0.0), o.optDouble("lon", 0.0)
    )
}
