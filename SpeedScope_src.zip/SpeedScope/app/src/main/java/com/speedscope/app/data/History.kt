package com.speedscope.app.data

import android.content.Context
import org.json.JSONObject
import java.io.File

/** Every report is its own file: filesDir/reports/<id>.json. Last 30 are kept. */
object History {
    private const val KEEP = 30

    private fun dir(ctx: Context): File = File(ctx.filesDir, "reports").also { it.mkdirs() }

    fun save(ctx: Context, r: Report) {
        File(dir(ctx), "${r.id}.json").writeText(ReportJson.toJson(r).toString())
        prune(ctx)
    }

    fun list(ctx: Context): List<Report> {
        val files = dir(ctx).listFiles()?.filter { it.extension == "json" } ?: emptyList()
        val out = ArrayList<Report>()
        for (f in files) {
            try { out.add(ReportJson.fromJson(JSONObject(f.readText()))) } catch (e: Exception) { /* skip corrupt file */ }
        }
        return out.sortedByDescending { it.startedAt }
    }

    fun get(ctx: Context, id: String): Report? = try {
        ReportJson.fromJson(JSONObject(File(dir(ctx), "$id.json").readText()))
    } catch (e: Exception) { null }

    fun delete(ctx: Context, id: String) {
        File(dir(ctx), "$id.json").delete()
    }

    private fun prune(ctx: Context) {
        val files = dir(ctx).listFiles()?.filter { it.extension == "json" }?.sortedByDescending { it.lastModified() } ?: return
        files.drop(KEEP).forEach { it.delete() }
    }
}
