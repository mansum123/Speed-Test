package com.speedscope.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.speedscope.app.data.f1
import com.speedscope.app.data.downsampleMinMax

@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(C.Card)
            .border(1.dp, C.Grid, RoundedCornerShape(20.dp)).padding(16.dp),
        content = content
    )
}

@Composable
fun Label(text: String, modifier: Modifier = Modifier) {
    Text(text, modifier, color = C.Muted, fontSize = 12.sp)
}

@Composable
fun Title(text: String, modifier: Modifier = Modifier) {
    Text(text, modifier, color = C.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
}

@Composable
fun Body(text: String, modifier: Modifier = Modifier, color: Color = C.Text) {
    Text(text, modifier, color = color, fontSize = 13.sp, lineHeight = 18.sp)
}

@Composable
fun Gap(h: Dp = 10.dp) {
    Spacer(Modifier.height(h))
}

@Composable
fun PrimaryButton(
    text: String, onClick: () -> Unit, modifier: Modifier = Modifier,
    color: Color = C.Blue, enabled: Boolean = true
) {
    val brush = if (!enabled) Brush.horizontalGradient(listOf(C.Card2, C.Card2))
    else if (color == C.Blue) Brush.horizontalGradient(listOf(C.BlueLight, C.Blue))
    else Brush.horizontalGradient(listOf(color, color))
    Box(
        modifier.height(52.dp).clip(RoundedCornerShape(26.dp)).background(brush)
            .clickable(enabled = enabled) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (enabled) Color.White else C.Muted, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
    }
}

/** Small outlined-looking text button used for secondary actions. */
@Composable
fun SoftButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, color: Color = C.Text, enabled: Boolean = true) {
    Box(
        modifier.clip(RoundedCornerShape(12.dp)).background(C.Card2)
            .clickable(enabled = enabled) { onClick() }
            .padding(horizontal = 14.dp, vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (enabled) color else C.Muted, fontSize = 13.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center)
    }
}

/** Equal-width segmented selector (2 to 4 short options). */
@Composable
fun <T> Segmented(
    items: List<T>, selected: T, label: (T) -> String,
    modifier: Modifier = Modifier, enabled: Boolean = true, onSelect: (T) -> Unit
) {
    Row(modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(C.Card2).padding(3.dp)) {
        for (item in items) {
            val on = item == selected
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(10.dp))
                    .background(if (on) Brush.horizontalGradient(listOf(C.BlueLight, C.Blue)) else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent)))
                    .clickable(enabled = enabled) { onSelect(item) }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    label(item), color = if (on) Color.White else C.Muted, fontSize = 12.5.sp,
                    fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal, maxLines = 1
                )
            }
        }
    }
}

/** Horizontally scrollable chips (for longer option lists). */
@Composable
fun <T> Chips(
    items: List<T>, selected: T, label: (T) -> String,
    modifier: Modifier = Modifier, enabled: Boolean = true, onSelect: (T) -> Unit
) {
    Row(modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        for (item in items) {
            val on = item == selected
            Box(
                Modifier.clip(RoundedCornerShape(20.dp))
                    .background(if (on) Brush.horizontalGradient(listOf(C.BlueLight, C.Blue)) else Brush.horizontalGradient(listOf(C.Card2, C.Card2)))
                    .clickable(enabled = enabled) { onSelect(item) }
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Text(label(item), color = if (on) Color.White else C.Muted, fontSize = 12.5.sp, maxLines = 1)
            }
        }
    }
}

@Composable
fun StatGrid(items: List<Pair<String, String>>, cols: Int = 3) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        for (row in items.chunked(cols)) {
            Row(Modifier.fillMaxWidth()) {
                for (cell in row) {
                    Column(Modifier.weight(1f)) {
                        Label(cell.first)
                        Text(cell.second, color = C.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
                repeat(cols - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

/** Thin progress bar (own drawing: no dependency on a specific Material3 overload). */
@Composable
fun Bar(frac: Float, color: Color = C.Blue, modifier: Modifier = Modifier) {
    val f = if (frac.isNaN()) 0f else frac.coerceIn(0f, 1f)
    Box(modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(C.Card2)) {
        Box(Modifier.fillMaxWidth(f).height(6.dp).clip(RoundedCornerShape(3.dp)).background(color))
    }
}

/** Rounds [v] up to a "nice" gauge maximum. */
fun niceMax(v: Double): Double {
    val steps = doubleArrayOf(10.0, 25.0, 50.0, 100.0, 250.0, 500.0, 1000.0, 2500.0, 5000.0, 10000.0)
    for (s in steps) if (v * 1.05 <= s) return s
    return steps.last()
}

/** 270-degree arc gauge with a gradient arc ([color] -> [color2]). [frac] is 0..1. */
@Composable
fun Gauge(frac: Float, big: String, unit: String, color: Color, size: Dp = 220.dp, caption: String = "", color2: Color = color) {
    val f = if (frac.isNaN()) 0f else frac.coerceIn(0f, 1f)
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(size)) {
            val sw = size.toPx() * 0.085f
            val d = Size(this.size.width - sw, this.size.height - sw)
            val tl = Offset(sw / 2, sw / 2)
            drawArc(C.Card2, 135f, 270f, false, tl, d, style = Stroke(sw, cap = StrokeCap.Round))
            if (f > 0.002f) {
                rotate(135f, Offset(this.size.width / 2, this.size.height / 2)) {
                    val brush = Brush.sweepGradient(
                        0f to color, 0.75f to color2, 1f to color2,
                        center = Offset(this.size.width / 2, this.size.height / 2)
                    )
                    drawArc(brush, 0f, 270f * f, false, tl, d, style = Stroke(sw, cap = StrokeCap.Round))
                }
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            if (caption.isNotEmpty()) Text(caption, color = C.Muted, fontSize = 12.sp)
            Text(big, color = C.Text, fontSize = (size.value * 0.2f).sp, fontWeight = FontWeight.Bold)
            Text(unit, color = C.Muted, fontSize = 14.sp)
        }
    }
}

/** Tappable card showing the selected server (design: "Server / name  >"). */
@Composable
fun ServerCard(name: String, loc: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(C.Card)
            .border(1.dp, C.Grid, RoundedCornerShape(16.dp)).clickable { onClick() }.padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("🖥", fontSize = 20.sp)
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Label("Server")
            Text(name + if (loc.isNotBlank()) ", " + loc else "", color = C.Text, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1)
        }
        Text("›", color = C.Muted, fontSize = 22.sp)
    }
}

/** 2x2 selectable cards (design: Long Run "Test Mode"). */
@Composable
fun <T> ModeGrid(items: List<T>, selected: T, title: (T) -> String, sub: (T) -> String, onSelect: (T) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        for (row in items.chunked(2)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                for (item in row) {
                    val on = item == selected
                    Column(
                        Modifier.weight(1f).heightIn(min = 76.dp).clip(RoundedCornerShape(16.dp))
                            .background(if (on) C.Blue.copy(alpha = 0.10f) else C.Card)
                            .border(if (on) 2.dp else 1.dp, if (on) C.Blue else C.Grid, RoundedCornerShape(16.dp))
                            .clickable { onSelect(item) }.padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
                    ) {
                        Text(title(item), color = if (on) C.Blue else C.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
                        Text(sub(item), color = C.Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
                    }
                }
                repeat(2 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

class Line(val values: List<Double>, val color: Color)

/** Largest value over all lines (+10 % headroom), at least 1. */
fun chartMax(lines: List<Line>): Double {
    var m = 0.0
    for (l in lines) for (v in l.values) if (v > m) m = v
    return if (m <= 0.0) 1.0 else m * 1.1
}

/** Multi-series line chart. Negative values are gaps (no reply). Long series are min/max-downsampled. */
@Composable
fun LineChart(lines: List<Line>, modifier: Modifier = Modifier, height: Dp = 120.dp, yMax: Double = chartMax(lines)) {
    Canvas(modifier.fillMaxWidth().height(height).clip(RoundedCornerShape(10.dp)).background(C.Card2)) {
        val w = this.size.width
        val h = this.size.height
        val pad = 6f
        for (g in 1..3) {
            val y = h * g / 4f
            drawLine(C.Grid, Offset(0f, y), Offset(w, y), 1f)
        }
        for (line in lines) {
            val v = downsampleMinMax(line.values, 600)
            if (v.size < 2) continue
            val path = Path()
            var pen = false
            for (i in v.indices) {
                val d = v[i]
                if (d < 0) { pen = false; continue }
                val x = w * i / (v.size - 1)
                val y = h - pad - (h - 2 * pad) * (d / yMax).toFloat().coerceIn(0f, 1f)
                if (!pen) { path.moveTo(x, y); pen = true } else path.lineTo(x, y)
            }
            drawPath(path, line.color, style = Stroke(width = 2.5f, join = StrokeJoin.Round, cap = StrokeCap.Round))
        }
    }
}

/** Panel with a title, a legend, the chart and the scale maximum. */
@Composable
fun ChartCard(
    title: String, lines: List<Line>, legend: List<Pair<String, Color>>, unit: String,
    height: Dp = 130.dp, yMax: Double = chartMax(lines)
) {
    Panel {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Title(title, Modifier.weight(1f))
            Label("max " + f1(yMax) + " " + unit)
        }
        Gap(8.dp)
        LineChart(lines, height = height, yMax = yMax)
        Gap(8.dp)
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            for (lg in legend) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(9.dp).clip(RoundedCornerShape(2.dp)).background(lg.second))
                    Text("  " + lg.first, color = C.Muted, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun Notice(text: String, color: Color = C.Orange) {
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(color.copy(alpha = 0.14f)).padding(12.dp)) {
        Text(text, color = color, fontSize = 13.sp, lineHeight = 18.sp)
    }
}

@Composable
fun ScreenHeader(title: String, onBack: (() -> Unit)?, trailing: @Composable () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) {
            Box(
                Modifier.clip(RoundedCornerShape(10.dp)).clickable { onBack() }.padding(end = 12.dp, top = 6.dp, bottom = 6.dp, start = 2.dp)
            ) { Text("←", color = C.Text, fontSize = 22.sp) }
        }
        Text(title, color = C.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        trailing()
    }
}
