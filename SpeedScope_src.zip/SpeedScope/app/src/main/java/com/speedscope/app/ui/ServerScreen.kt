package com.speedscope.app.ui

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.location.LocationManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.speedscope.app.engine.Server
import com.speedscope.app.engine.Servers
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@SuppressLint("MissingPermission")
private fun lastKnown(ctx: Context): Pair<Double, Double>? = try {
    val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    var best: android.location.Location? = null
    for (p in lm.getProviders(true)) {
        val l = lm.getLastKnownLocation(p) ?: continue
        if (best == null || l.time > best.time) best = l
    }
    best?.let { Pair(it.latitude, it.longitude) }
} catch (e: Exception) { null }

@Composable
private fun ServerRow(s: Server, selected: Boolean, onPick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
            .background(if (selected) C.Blue.copy(alpha = 0.22f) else C.Card2)
            .clickable { onPick() }.padding(12.dp)
    ) {
        Column(Modifier.weight(1f)) {
            Text(s.name, color = C.Text, fontSize = 14.sp, maxLines = 1)
            if (s.loc.isNotBlank()) Label(s.loc)
        }
        if (selected) Text("✓", color = C.Blue, fontSize = 18.sp)
    }
}

@Composable
fun ServerScreen(ui: UiPrefs, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Server>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var cName by remember { mutableStateOf("") }
    var cDown by remember { mutableStateOf("") }
    var cUp by remember { mutableStateOf("") }
    var cPing by remember { mutableStateOf("") }

    fun search(near: Boolean) {
        scope.launch {
            loading = true; error = null
            try {
                val loc = if (near) lastKnown(ctx) else null
                if (near && loc == null) error = "No location available yet. Turn on location and try again, or search by city name."
                val list = withContext(Dispatchers.IO) { Servers.ookla(query.ifBlank { null }, loc?.first, loc?.second) }
                results = list
                if (list.isEmpty() && error == null) error = "No servers found."
            } catch (e: Exception) {
                error = "Search failed: " + (e.message ?: e.javaClass.simpleName)
            } finally { loading = false }
        }
    }

    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) search(true) else error = "Location permission denied. Search by city name instead."
    }

    fun pick(s: Server) { ui.updateServer(s); onBack() }

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader("Test server", onBack)
        Panel {
            Title("Current")
            Gap(6.dp)
            Body(ui.server.name + if (ui.server.loc.isNotBlank()) " - " + ui.server.loc else "")
            Gap(8.dp)
            ServerRow(Servers.CF, ui.server.id == "cf") { pick(Servers.CF) }
        }
        Panel {
            Title("Find an Ookla (Speedtest.net) server")
            Gap(4.dp)
            Label("Search by city, country or provider name. Results use the legacy download/upload files of each server.")
            Gap(8.dp)
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                label = { Text("City / provider") }, modifier = Modifier.fillMaxWidth()
            )
            Gap(8.dp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PrimaryButton(if (loading) "Searching…" else "Search", { search(false) }, Modifier.weight(1f), enabled = !loading)
                PrimaryButton("Near me", {
                    permission.launch(Manifest.permission.ACCESS_FINE_LOCATION)
                }, Modifier.weight(1f), color = C.Teal, enabled = !loading)
            }
            val e = error
            if (e != null) { Gap(8.dp); Body(e, color = C.Orange) }
            if (results.isNotEmpty()) {
                Gap(10.dp)
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (s in results) ServerRow(s, ui.server.id == s.id) { pick(s) }
                }
            }
        }
        Panel {
            Title("Custom server")
            Gap(4.dp)
            Label("Any HTTP(S) file URL for download. Upload URL must accept POST (leave empty to reuse the download URL).")
            Gap(8.dp)
            OutlinedTextField(cName, { cName = it }, singleLine = true, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
            Gap(6.dp)
            OutlinedTextField(cDown, { cDown = it.trim() }, singleLine = true, label = { Text("Download URL (https://...)") }, modifier = Modifier.fillMaxWidth())
            Gap(6.dp)
            OutlinedTextField(cUp, { cUp = it.trim() }, singleLine = true, label = { Text("Upload URL (optional)") }, modifier = Modifier.fillMaxWidth())
            Gap(6.dp)
            OutlinedTextField(cPing, { cPing = it.trim() }, singleLine = true, label = { Text("Ping URL (optional)") }, modifier = Modifier.fillMaxWidth())
            Gap(10.dp)
            val valid = cDown.startsWith("http://") || cDown.startsWith("https://")
            PrimaryButton("Use custom server", {
                val name = cName.ifBlank { "Custom server" }
                pick(Server("custom:$name", name, "custom", "", cDown, cUp, cPing))
            }, Modifier.fillMaxWidth(), enabled = valid)
        }
        Gap(24.dp)
    }
}
