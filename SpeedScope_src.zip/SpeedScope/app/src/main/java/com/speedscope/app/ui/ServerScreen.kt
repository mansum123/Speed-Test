package com.speedscope.app.ui

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.text.input.ImeAction
import com.speedscope.app.engine.Loc
import com.speedscope.app.engine.Server
import com.speedscope.app.engine.Servers
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
private fun ServerRow(s: Server, sub: String, selected: Boolean, onPick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
            .background(if (selected) C.Blue.copy(alpha = 0.14f) else C.Card2)
            .clickable { onPick() }.padding(12.dp),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(s.name, color = C.Text, fontSize = 14.sp, maxLines = 1)
            if (sub.isNotBlank()) Label(sub)
        }
        if (selected) Text("✓", color = C.Blue, fontSize = 18.sp)
    }
}

@Composable
fun ServerScreen(ui: UiPrefs, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Server>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var here by remember { mutableStateOf<Pair<Double, Double>?>(null) }
    var cName by remember { mutableStateOf("") }
    var cDown by remember { mutableStateOf("") }
    var cUp by remember { mutableStateOf("") }
    var cPing by remember { mutableStateOf("") }

    /** Loads the server list: nearest first when the location is known, otherwise filtered by [query]. */
    fun load() {
        scope.launch {
            loading = true; error = null
            try {
                val loc = Loc.lastKnown(ctx)
                here = loc
                val list = withContext(Dispatchers.IO) { Servers.ookla(query.ifBlank { null }, loc?.first, loc?.second) }
                results = list
                if (list.isEmpty()) error = "No servers found."
            } catch (e: Exception) {
                error = "Server list failed: " + (e.message ?: e.javaClass.simpleName)
            } finally { loading = false }
        }
    }

    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { _ ->
        if (Loc.hasPermission(ctx)) load() else error = "Location permission denied. Search by city name instead."
    }

    LaunchedEffect(Unit) { load() }

    fun pick(s: Server) { ui.updateServer(s); onBack() }

    fun km(s: Server): String {
        val h = here ?: return ""
        if (s.lat == 0.0 && s.lon == 0.0) return ""
        val d = Servers.haversineKm(h.first, h.second, s.lat, s.lon)
        return (if (d >= 100) d.toInt().toString() else String.format(java.util.Locale.US, "%.1f", d)) + " km"
    }

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader("Test server", onBack)
        Panel {
            Title("Search server")
            Gap(8.dp)
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                label = { Text("City / country / provider") }, modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { load() })
            )
            Gap(8.dp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PrimaryButton(if (loading) "Loading…" else "Search", { load() }, Modifier.weight(1f), enabled = !loading)
                PrimaryButton("Use my location", {
                    if (Loc.hasPermission(ctx)) load() else permission.launch(Manifest.permission.ACCESS_FINE_LOCATION)
                }, Modifier.weight(1f), color = C.Teal, enabled = !loading)
            }
            if (here == null) { Gap(6.dp); Label("Location is off: distances are not shown and the list is not sorted by distance.") }
            val e = error
            if (e != null) { Gap(8.dp); Body(e, color = C.Orange) }
        }
        Panel {
            Title("Servers")
            Gap(4.dp)
            Label("Current: " + ui.server.name + if (ui.server.loc.isNotBlank()) " - " + ui.server.loc else "")
            Gap(8.dp)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ServerRow(Servers.AUTO, Servers.AUTO.loc + " (needs location for best result)", ui.server.id == "auto") { pick(Servers.AUTO) }
                ServerRow(Servers.CF, Servers.CF.loc, ui.server.id == "cf") { pick(Servers.CF) }
                for (s in results) {
                    val d = km(s)
                    ServerRow(s, listOf(s.loc, d).filter { it.isNotBlank() }.joinToString("  ·  "), ui.server.id == s.id) { pick(s) }
                }
            }
        }
        Panel {
            Title("Custom server")
            Gap(4.dp)
            Label("Any HTTP(S) file URL for download. Upload URL must accept POST (leave empty to reuse the download URL).")
            Gap(8.dp)
            OutlinedTextField(cName, { cName = it }, singleLine = true, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
            Gap(6.dp)
            OutlinedTextField(cDown, { cDown = it.trim() }, singleLine = true, label = { Text("Download URL (https://...)") }, modifier = Modifier.fillMaxWidth())
            Gap(6.dp)
            OutlinedTextField(cUp, { cUp = it.trim() }, singleLine = true, label = { Text("Upload URL (optional)") }, modifier = Modifier.fillMaxWidth())
            Gap(6.dp)
            OutlinedTextField(cPing, { cPing = it.trim() }, singleLine = true, label = { Text("Ping URL (optional)") }, modifier = Modifier.fillMaxWidth())
            Gap(10.dp)
            val valid = cDown.startsWith("http://") || cDown.startsWith("https://")
            PrimaryButton("Use custom server", {
                val name = cName.ifBlank { "Custom server" }
                pick(Server("custom:$name", name, "custom", "", cDown, cUp, cPing))
            }, Modifier.fillMaxWidth(), enabled = valid)
        }
        Gap(24.dp)
    }
}
