package com.speedscope.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.speedscope.app.data.*
import com.speedscope.app.monitor.Bucket
import com.speedscope.app.monitor.IncidentRow
import com.speedscope.app.monitor.MonitorDb
import com.speedscope.app.monitor.MonitorService
import com.speedscope.app.monitor.MonitorState
import com.speedscope.app.monitor.SessionRow
import com.speedscope.app.report.Blocks
import com.speedscope.app.report.ReportExporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val TARGETS = listOf("8.8.8.8", "1.1.1.1", "gateway", "custom")
private val INTERVALS = listOf(1, 2, 5, 10, 30, 60)

private fun targetLabel(t: String) = when (t) {
    "8.8.8.8" -> "Google DNS"
    "1.1.1.1" -> "Cloudflare"
    "gateway" -> "Router"
    else -> "Custom"
}

private fun clock(ms: Long): String = SimpleDateFormat("dd MMM HH:mm:ss", Locale.getDefault()).format(Date(ms))

@Composable
private fun BigTile(label: String, value: String, color: Color, modifier: Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Label(label)
        Text(value, color = color, fontSize = 19.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
fun MonitorScreen(ui: UiPrefs, onOpenSession: (Long) -> Unit, onHistory: () -> Unit) {
    val ctx = LocalContext.current
    val live by MonitorState.live.collectAsState()
    val running = live.running
    val lastSession by produceState<SessionRow?>(null, running) {
        value = withContext(Dispatchers.IO) { MonitorDb.get(ctx).sessions().firstOrNull() }
    }
    var error by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader("Ping Monitor", null) { SoftButton("History", onHistory) }

        if (running) {
            val statusText: String
            val statusColor: Color
            when {
                live.paused -> { statusText = "PAUSED"; statusColor = C.Orange }
                live.outage -> { statusText = "OUTAGE"; statusColor = C.Red }
                live.total == 0 -> { statusText = "STARTING…"; statusColor = C.Muted }
                live.last < 0 -> { statusText = "PROBE DROPPED"; statusColor = C.Orange }
                else -> { statusText = "ONLINE"; statusColor = C.Green }
            }
            Panel {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(statusText, color = statusColor, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                        Label("Target: " + live.target + "  ·  via " + live.method.ifBlank { "ICMP" })
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(if (live.last < 0) "–" else fmtMs(live.last), color = C.Purple, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Label("last probe")
                    }
                }
                Gap(14.dp)
                Row(Modifier.fillMaxWidth()) {
                    BigTile("Availability", f2(live.availability) + "%", if (live.availability >= 99.0) C.Green else C.Orange, Modifier.weight(1.3f))
                    BigTile("Probes ok", live.ok.toString() + "/" + live.total, C.Text, Modifier.weight(1f))
                    BigTile("Outages", live.incidents.toString(), if (live.incidents > 0) C.Red else C.Text, Modifier.weight(1f))
                    BigTile("Dropped", live.dropped.toString(), C.Text, Modifier.weight(1f))
                }
                Gap(8.dp)
                Label("Running for " + fmtDur(((System.currentTimeMillis() - live.startedAt) / 1000).toInt().coerceAtLeast(0)) +
                    "  ·  outage = 3 or more failed probes in a row")
            }
            if (live.recent.size >= 2) {
                ChartCard("Latency (last ${live.recent.size} probes)", listOf(Line(live.recent, C.Purple)), listOf("Ping" to C.Purple), "ms")
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (live.paused) PrimaryButton("Resume", { MonitorService.send(ctx, MonitorService.ACTION_RESUME) }, Modifier.weight(1f), color = C.Green)
                else PrimaryButton("Pause", { MonitorService.send(ctx, MonitorService.ACTION_PAUSE) }, Modifier.weight(1f), color = C.Orange)
                PrimaryButton("Stop & save", { MonitorService.send(ctx, MonitorService.ACTION_STOP) }, Modifier.weight(1f), color = C.Red)
            }
            Label("Keeps monitoring with the screen off. Paused time is not counted in availability.")
        } else {
            Panel {
                Title("Target")
                Gap(8.dp)
                Segmented(TARGETS, ui.monTarget, { targetLabel(it) }) { ui.setMonTarget(it) }
                if (ui.monTarget == "custom") {
                    Gap(8.dp)
                    OutlinedTextField(
                        value = ui.monCustom, onValueChange = { ui.setMonCustom(it.trim()) }, singleLine = true,
                        label = { Text("IP or host name (e.g. 192.168.1.1)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Gap(14.dp)
                Title("Probe every")
                Gap(8.dp)
                Chips(INTERVALS, ui.monInterval, { "$it s" }) { ui.setMonInterval(it) }
            }
            val host = ui.monHost()
            if (error != null) Notice(error ?: "", C.Red)
            PrimaryButton("Start monitoring", {
                if (host.isBlank()) error = "Enter a host or IP first."
                else { error = null; MonitorService.start(ctx, host, ui.monInterval) }
            }, Modifier.fillMaxWidth(), color = C.Green)
            Panel {
                Title("How it works")
                Gap(6.dp)
                Body("Probes the target with ICMP ping (falls back to TCP:443 if ICMP is blocked). 1 or 2 failures in a row are counted as dropped probes; 3 or more in a row are an outage, which starts at the first failed probe and ends at the first success. When an outage starts, the gateway, internet and DNS are compared to show where the problem likely is.", color = C.Muted)
            }
            val ls = lastSession
            if (ls != null) {
                Panel {
                    Title("Last session")
                    Gap(4.dp)
                    Label(clock(ls.startedAt) + "  ·  " + ls.target + "  ·  " + fmtDur((ls.durationMs / 1000).toInt()))
                    Gap(8.dp)
                    Text(f2(ls.availability) + " % available  ·  " + ls.ok + "/" + ls.total + " probes", color = C.Purple, fontSize = 14.sp)
                    Gap(10.dp)
                    SoftButton("Open report & export", { onOpenSession(ls.id) }, Modifier.fillMaxWidth())
                }
            }
        }
        Gap(24.dp)
    }
}

private class MonData(
    val session: SessionRow, val incidents: List<IncidentRow>, val rtt: Stat,
    val jitter: Double, val buckets: List<Bucket>
)

/** Report for one saved monitor session, with PDF/PNG export and delete. */
@Composable
fun MonitorReportScreen(sessionId: Long, onBack: () -> Unit, onDeleted: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var confirm by remember { mutableStateOf(false) }
    val mon by MonitorState.live.collectAsState()

    val data by produceState<MonData?>(null, sessionId) {
        value = withContext(Dispatchers.IO) {
            val db = MonitorDb.get(ctx)
            val s = db.session(sessionId)
            if (s == null) null else {
                val rtts = db.rtts(sessionId)
                MonData(s, db.incidents(sessionId), statsOf(rtts), jitter(rtts), db.buckets(sessionId))
            }
        }
    }

    fun export(png: Boolean) {
        val d = data ?: return
        scope.launch {
            busy = true; error = null
            try {
                val file = withContext(Dispatchers.IO) {
                    val blocks = Blocks.monitor(d.session, d.rtt, d.jitter, d.buckets, d.incidents)
                    val name = ReportExporter.fileName("monitor", d.session.startedAt, if (png) "png" else "pdf")
                    if (png) ReportExporter.png(ctx, blocks, name) else ReportExporter.pdf(ctx, blocks, name)
                }
                ReportExporter.share(ctx, file, if (png) "image/png" else "application/pdf")
            } catch (e: Exception) {
                error = "Export failed: " + (e.message ?: e.javaClass.simpleName)
            } finally { busy = false }
        }
    }

    val d = data
    val active = mon.running && mon.sessionId == sessionId
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader("Monitor report", onBack) {
            if (!active) SoftButton("Delete", { confirm = true }, color = C.Red)
        }
        if (d == null) {
            Label("Loading…")
        } else {
            val s = d.session
            if (active) Notice("This session is still running. Reopen the report after stopping to see final numbers.", C.Blue)
            ExportRow(busy, error, { export(false) }, { export(true) })
            Panel {
                Title("Ping: " + s.target)
                Gap(4.dp)
                Label(clock(s.startedAt) + " → " + (if (s.endedAt > 0) clock(s.endedAt) else "running"))
                Label(fmtDur((s.durationMs / 1000).toInt()) + "  ·  every " + (s.intervalMs / 1000) + " s  ·  " + s.method.ifBlank { "ICMP" })
            }
            val longest = d.incidents.maxOfOrNull { if (it.endMs > 0) it.endMs - it.startMs else 0L } ?: 0L
            Panel {
                Title("Availability")
                Gap(8.dp)
                Text(f2(s.availability) + " %", color = if (s.availability >= 99.0) C.Green else C.Orange, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Gap(8.dp)
                StatGrid(listOf(
                    "Probes (ok / total)" to "${s.ok} / ${s.total}",
                    "Dropped probes" to s.dropped.toString(),
                    "Outages (3+ in a row)" to d.incidents.size.toString(),
                    "Longest outage" to (if (longest > 0) fmtDur((longest / 1000).toInt().coerceAtLeast(1)) else "–"),
                    "Paused time" to "excluded"
                ))
            }
            Panel {
                Title("Latency (successful probes)")
                Gap(8.dp)
                StatGrid(listOf(
                    "Average" to fmtMs(d.rtt.avg), "Minimum" to fmtMs(d.rtt.min), "Maximum" to fmtMs(d.rtt.max),
                    "95th percentile" to fmtMs(d.rtt.p95), "Median" to fmtMs(d.rtt.median), "Jitter" to fmtMs(d.jitter)
                ))
            }
            if (d.buckets.isNotEmpty()) {
                ChartCard(
                    "Latency over time",
                    listOf(
                        Line(d.buckets.map { it.avg }, C.Purple),
                        Line(d.buckets.map { it.max }, C.Orange)
                    ),
                    listOf("Average" to C.Purple, "Max in bucket" to C.Orange), "ms"
                )
                ChartCard(
                    "Failed probes over time",
                    listOf(Line(d.buckets.map { it.fails.toDouble() }, C.Red)),
                    listOf("Failed probes" to C.Red), "probes"
                )
            }
            Panel {
                Title("Outages")
                Gap(6.dp)
                if (d.incidents.isEmpty()) Body("No outage detected (an outage = 3 or more consecutive failed probes).", color = C.Muted)
                else Label("${d.incidents.size} outage(s) detected. Details below.")
            }
            d.incidents.forEachIndexed { i, inc ->
                Panel {
                    Title("Outage ${i + 1}")
                    Gap(4.dp)
                    Label(clock(inc.startMs) + "  ·  " +
                        (if (inc.endMs > 0) fmtDur(((inc.endMs - inc.startMs) / 1000).toInt().coerceAtLeast(1)) else "ongoing") +
                        "  ·  " + inc.fails + " failed probes")
                    Label("Latency before: " + fmtMs(inc.beforeMs) + "   after: " + fmtMs(inc.afterMs))
                    if (inc.diag.isNotBlank()) {
                        Gap(8.dp)
                        Body(inc.diag, color = C.Muted)
                    }
                }
            }
            Label("Diagnosis compares gateway, internet and DNS at the moment an outage was detected. 'No reply' hops may simply block ICMP; this is indicative, not proof of where the fault is.")
        }
        Gap(24.dp)
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Delete this monitor session?") },
            text = { Text("All probes and outages of the session will be removed.") },
            confirmButton = {
                TextButton({ confirm = false; MonitorDb.get(ctx).delete(sessionId); onDeleted() }) { Text("Delete", color = C.Red) }
            },
            dismissButton = { TextButton({ confirm = false }) { Text("Cancel") } }
        )
    }
}
