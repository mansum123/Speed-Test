package com.speedscope.app.report

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.speedscope.app.data.*
import com.speedscope.app.engine.Extras
import com.speedscope.app.engine.bandOf
import com.speedscope.app.engine.chanOf
import com.speedscope.app.monitor.Bucket
import com.speedscope.app.monitor.IncidentRow
import com.speedscope.app.monitor.SessionRow
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Ser(val name: String, val values: List<Double>, val color: Int)

sealed class Block {
    class H(val text: String, val size: Float = 16f) : Block()
    class P(val text: String, val color: Int = 0xFF334155.toInt(), val size: Float = 10f) : Block()
    class KV(val rows: List<Pair<String, String>>) : Block()
    class Chart(val title: String, val series: List<Ser>, val unit: String) : Block()
    class Rows(val head: List<String>, val rows: List<List<String>>) : Block()
}

private class Paper(val w: Float, val pageH: Float, var canvas: Canvas?, val next: (() -> Canvas?)?) {
    val m = 36f
    var y = m
    fun need(h: Float) {
        val n = next
        if (n != null && y + h > pageH - m) { canvas = n(); y = m }
    }
}

private fun paint(size: Float, color: Int, bold: Boolean = false): Paint =
    Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = size
        this.color = color
        typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
    }

private fun wrap(text: String, p: Paint, maxW: Float): List<String> {
    val out = ArrayList<String>()
    for (para in text.split('\n')) {
        var line = ""
        for (word in para.split(' ')) {
            val t = if (line.isEmpty()) word else "$line $word"
            if (p.measureText(t) <= maxW) line = t else { if (line.isNotEmpty()) out.add(line); line = word }
        }
        out.add(line)
    }
    return out
}

private fun fit(text: String, p: Paint, w: Float): String {
    if (p.measureText(text) <= w) return text
    var t = text
    while (t.length > 1 && p.measureText("$t…") > w) t = t.dropLast(1)
    return "$t…"
}

private fun render(blocks: List<Block>, pg: Paper) {
    val cw = pg.w - 2 * pg.m
    for (b in blocks) {
        when (b) {
            is Block.H -> {
                val p = paint(b.size, 0xFF0F172A.toInt(), true)
                pg.need(b.size + 14)
                pg.y += 4
                pg.canvas?.drawText(b.text, pg.m, pg.y + b.size, p)
                pg.y += b.size + 8
            }
            is Block.P -> {
                val p = paint(b.size, b.color)
                for (l in wrap(b.text, p, cw)) {
                    pg.need(b.size + 4)
                    pg.canvas?.drawText(l, pg.m, pg.y + b.size, p)
                    pg.y += b.size + 4
                }
                pg.y += 4
            }
            is Block.KV -> {
                val cols = 3
                val cellW = cw / cols
                val lp = paint(8.5f, 0xFF64748B.toInt())
                val vp = paint(12f, 0xFF0F172A.toInt(), true)
                var i = 0
                while (i < b.rows.size) {
                    pg.need(34f)
                    for (c in 0 until cols) {
                        val item = b.rows.getOrNull(i + c) ?: break
                        val x = pg.m + c * cellW
                        pg.canvas?.drawText(fit(item.first, lp, cellW - 6), x, pg.y + 10, lp)
                        pg.canvas?.drawText(fit(item.second, vp, cellW - 6), x, pg.y + 26, vp)
                    }
                    pg.y += 34f
                    i += cols
                }
                pg.y += 6
            }
            is Block.Chart -> {
                val h = 110f
                pg.need(h + 44)
                val tp = paint(10f, 0xFF0F172A.toInt(), true)
                pg.canvas?.drawText(b.title, pg.m, pg.y + 10, tp)
                pg.y += 16
                val top = pg.y
                val c = pg.canvas
                val all = b.series.flatMap { it.values }
                val maxV = (all.maxOrNull() ?: 1.0).let { if (it <= 0.0) 1.0 else it * 1.1 }
                if (c != null) {
                    val grid = Paint().apply { color = 0xFFE2E8F0.toInt(); strokeWidth = 0.6f }
                    for (g in 0..3) c.drawLine(pg.m, top + h * g / 3f, pg.m + cw, top + h * g / 3f, grid)
                    for (s in b.series) {
                        val v = downsampleMinMax(s.values, 500)
                        if (v.size < 2) continue
                        val path = Path()
                        v.forEachIndexed { i, d ->
                            val x = pg.m + cw * i / (v.size - 1)
                            val yy = top + h - (h * (d / maxV)).toFloat().coerceIn(0f, h)
                            if (i == 0) path.moveTo(x, yy) else path.lineTo(x, yy)
                        }
                        val lp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            style = Paint.Style.STROKE; strokeWidth = 1.2f; color = s.color
                        }
                        c.drawPath(path, lp)
                    }
                    c.drawText("max ${f1(maxV)} ${b.unit}", pg.m + 2, top + 9, paint(8f, 0xFF64748B.toInt()))
                }
                pg.y += h + 6
                var lx = pg.m
                for (s in b.series) {
                    val sp = Paint().apply { color = s.color }
                    pg.canvas?.drawRect(lx, pg.y, lx + 8, pg.y + 8, sp)
                    val lp = paint(8.5f, 0xFF334155.toInt())
                    pg.canvas?.drawText(s.name, lx + 11, pg.y + 8, lp)
                    lx += 24 + lp.measureText(s.name)
                }
                pg.y += 20
            }
            is Block.Rows -> {
                val cwid = cw / b.head.size
                val hp = paint(9f, 0xFF0F172A.toInt(), true)
                val rp = paint(9f, 0xFF334155.toInt())
                pg.need(18f)
                b.head.forEachIndexed { i, t -> pg.canvas?.drawText(fit(t, hp, cwid - 4), pg.m + i * cwid, pg.y + 10, hp) }
                pg.y += 15
                for (r in b.rows) {
                    pg.need(14f)
                    r.forEachIndexed { i, t -> pg.canvas?.drawText(fit(t, rp, cwid - 4), pg.m + i * cwid, pg.y + 10, rp) }
                    pg.y += 13
                }
                pg.y += 8
            }
        }
    }
}

object Blocks {
    private val GREEN = 0xFF10B981.toInt()
    private val ORANGE = 0xFFF59E0B.toInt()
    private val PURPLE = 0xFF8B5CF6.toInt()
    private val RED = 0xFFEF4444.toInt()
    private val dayFmt get() = SimpleDateFormat("dd MMM HH:mm:ss", Locale.getDefault())

    private fun sp(v: Double, u: SpeedUnit) = fmtSpeed(v, u) + " " + u.label

    fun speed(r: Report, unit: SpeedUnit): List<Block> {
        val b = ArrayList<Block>()
        b.add(Block.H("SpeedScope - " + (if (r.kind == "long") "Long Run" else "Speed Test") + " Report", 20f))
        b.add(Block.P("${fmtTime(r.startedAt)}   |   ${r.mode.label}   |   ${r.conn.label}   |   ${fmtDur(r.samples.size)} measured"))
        b.add(Block.P("Server: ${r.server}" + if (r.serverLoc.isNotBlank()) " - ${r.serverLoc}" else ""))
        if (r.partial) b.add(Block.P("This run was stopped early or hit an error, so the result is partial.", 0xFFB45309.toInt()))

        if (r.hasDown) {
            val dv = r.downValues(); val s = statsOf(dv); val st = statsOf(steady(dv))
            b.add(Block.H("Download", 13f))
            b.add(Block.KV(listOf(
                "Average" to sp(s.avg, unit), "Steady avg (after 3 s)" to sp(st.avg, unit), "Peak" to sp(s.max, unit),
                "Minimum" to sp(s.min, unit), "Slowest 10% (P10)" to sp(st.p10, unit), "Median" to sp(st.median, unit)
            )))
            b.add(Block.Chart("Download speed over time", listOf(Ser("Download", dv.map { it * unit.perMbps }, GREEN)), unit.label))
        }
        if (r.hasUp) {
            val uv = r.upValues(); val s = statsOf(uv); val st = statsOf(steady(uv))
            b.add(Block.H("Upload", 13f))
            b.add(Block.KV(listOf(
                "Average" to sp(s.avg, unit), "Steady avg (after 3 s)" to sp(st.avg, unit), "Peak" to sp(s.max, unit),
                "Minimum" to sp(s.min, unit), "Slowest 10% (P10)" to sp(st.p10, unit), "Median" to sp(st.median, unit)
            )))
            b.add(Block.Chart("Upload speed over time", listOf(Ser("Upload", uv.map { it * unit.perMbps }, ORANGE)), unit.label))
        }
        val pv = r.pings()
        b.add(Block.H("Latency", 13f))
        b.add(Block.KV(listOf(
            "Idle ping" to fmtMs(r.idlePingMs),
            "Ping under load (avg)" to (if (pv.isEmpty()) "–" else fmtMs(pv.average())),
            "Jitter" to (if (pv.size < 2) "–" else fmtMs(jitter(pv)))
        )))

        val boosts = ArrayList<String>()
        boostOf(r.downValues())?.let { boosts.add(boostText("Download", it, unit)) }
        boostOf(r.upValues())?.let { boosts.add(boostText("Upload", it, unit)) }
        if (boosts.isNotEmpty()) {
            b.add(Block.H("Boost check", 13f))
            boosts.forEach { b.add(Block.P(it)) }
            b.add(Block.P("An observed reduction after the first seconds can have many causes (server, Wi-Fi, congestion, ISP policy). It is an observation, not proof of throttling.", 0xFF64748B.toInt(), 8.5f))
        }

        val s = r.snap
        b.add(Block.H("Network snapshot (at start)", 13f))
        b.add(Block.KV(listOf(
            "Connection" to s.type.ifBlank { "–" },
            "Wi-Fi name" to s.ssid.ifBlank { "–" },
            "Signal" to (if (s.rssi != 0) "${s.rssi} dBm" else "–"),
            "Link speed" to (if (s.linkMbps > 0) "${s.linkMbps} Mbps" else "–"),
            "Band / channel" to (if (s.freqMhz > 0) "${bandOf(s.freqMhz)} / ch ${chanOf(s.freqMhz)}" else "–"),
            "Gateway" to s.gateway.ifBlank { "–" },
            "Gateway latency" to fmtMs(s.gatewayMs),
            "DNS lookup" to fmtMs(s.dnsMs)
        )))
        val ex = Extras.lines()
        if (ex.isNotEmpty()) { b.add(Block.H("Other tools", 13f)); ex.forEach { b.add(Block.P(it)) } }
        b.add(Block.P("Generated by SpeedScope. Results depend on the chosen server, route and device.", 0xFF94A3B8.toInt(), 8f))
        return b
    }

    private fun boostText(name: String, bo: Boost, u: SpeedUnit): String =
        "$name: first 30 s average ${sp(bo.first, u)} vs. after 40 s ${sp(bo.after, u)} -> " +
            (if (bo.reduced) "observed performance reduction of ${f0(bo.dropPct)}%." else "no significant reduction (${f0(bo.dropPct)}% change).")

    fun monitor(s: SessionRow, rtt: Stat, jit: Double, buckets: List<Bucket>, inc: List<IncidentRow>): List<Block> {
        val b = ArrayList<Block>()
        b.add(Block.H("SpeedScope - Ping Monitor Report", 20f))
        val end = if (s.endedAt > 0) dayFmt.format(Date(s.endedAt)) else "running"
        b.add(Block.P("Target: ${s.target}   |   ${dayFmt.format(Date(s.startedAt))} -> $end   |   ${fmtDur((s.durationMs / 1000).toInt())}"))
        b.add(Block.P("Probe every ${s.intervalMs / 1000} s via ${s.method.ifBlank { "ICMP" }}"))
        b.add(Block.H("Availability", 13f))
        val longest = inc.maxOfOrNull { if (it.endMs > 0) it.endMs - it.startMs else 0L } ?: 0L
        b.add(Block.KV(listOf(
            "Availability" to f2(s.availability) + " %",
            "Probes (ok / total)" to "${s.ok} / ${s.total}",
            "Isolated dropped probes" to s.dropped.toString(),
            "Outages (3+ in a row)" to inc.size.toString(),
            "Longest outage" to (if (longest > 0) fmtDur((longest / 1000).toInt().coerceAtLeast(1)) else "–"),
            "Paused time" to "excluded"
        )))
        b.add(Block.H("Latency (successful probes)", 13f))
        b.add(Block.KV(listOf(
            "Average" to fmtMs(rtt.avg), "Minimum" to fmtMs(rtt.min), "Maximum" to fmtMs(rtt.max),
            "95th percentile" to fmtMs(rtt.p95), "Median" to fmtMs(rtt.median), "Jitter" to fmtMs(jit)
        )))
        if (buckets.isNotEmpty()) {
            b.add(Block.Chart("Latency over time", listOf(
                Ser("Average", buckets.map { if (it.avg < 0) 0.0 else it.avg }, PURPLE),
                Ser("Max in bucket", buckets.map { if (it.max < 0) 0.0 else it.max }, ORANGE)
            ), "ms"))
            b.add(Block.Chart("Failed probes per time bucket", listOf(Ser("Failed", buckets.map { it.fails.toDouble() }, RED)), "probes"))
        }
        b.add(Block.H("Outages", 13f))
        if (inc.isEmpty()) b.add(Block.P("No outage detected (an outage = 3 or more consecutive failed probes)."))
        else {
            b.add(Block.Rows(listOf("Started", "Duration", "Failed probes", "Latency before", "Latency after"),
                inc.map {
                    listOf(
                        dayFmt.format(Date(it.startMs)),
                        if (it.endMs > 0) fmtDur(((it.endMs - it.startMs) / 1000).toInt().coerceAtLeast(1)) else "ongoing",
                        it.fails.toString(), fmtMs(it.beforeMs), fmtMs(it.afterMs)
                    )
                }))
            inc.forEachIndexed { i, it ->
                if (it.diag.isNotBlank()) { b.add(Block.P("Outage ${i + 1} - indicative diagnosis:", 0xFF0F172A.toInt(), 9f)); b.add(Block.P(it.diag, 0xFF334155.toInt(), 8.5f)) }
            }
        }
        b.add(Block.P("Diagnosis compares gateway, internet and DNS at the moment an outage was detected. Hops showing 'no reply' may only block ICMP; this is indicative, not proof of where the fault is.", 0xFF64748B.toInt(), 8.5f))
        return b
    }
}

object ReportExporter {
    private fun dir(ctx: Context): File = File(ctx.cacheDir, "exports").also { it.mkdirs() }
    private fun stamp(ms: Long) = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date(ms))

    fun fileName(prefix: String, ms: Long, ext: String) = "SpeedScope_${prefix}_${stamp(ms)}.$ext"

    fun pdf(ctx: Context, blocks: List<Block>, name: String): File {
        val doc = PdfDocument()
        val w = 595; val h = 842
        var pageNo = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, pageNo).create())
        val paper = Paper(w.toFloat(), h.toFloat(), page.canvas) {
            doc.finishPage(page)
            pageNo++
            page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, pageNo).create())
            page.canvas
        }
        render(blocks, paper)
        doc.finishPage(page)
        val f = File(dir(ctx), name)
        FileOutputStream(f).use { doc.writeTo(it) }
        doc.close()
        return f
    }

    fun png(ctx: Context, blocks: List<Block>, name: String): File {
        val w = 595f
        val scale = 2f
        val dry = Paper(w, Float.MAX_VALUE, null, null)
        render(blocks, dry)
        val h = dry.y + dry.m
        val bmp = Bitmap.createBitmap((w * scale).toInt(), (h * scale).toInt(), Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.WHITE)
        c.scale(scale, scale)
        render(blocks, Paper(w, Float.MAX_VALUE, c, null))
        val f = File(dir(ctx), name)
        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bmp.recycle()
        return f
    }

    fun share(ctx: Context, file: File, mime: String) {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", file)
        val send = Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(send, "Share report").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
