package com.speedscope.app.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.speedscope.app.data.*
import com.speedscope.app.engine.RunConfig
import com.speedscope.app.engine.TestService
import com.speedscope.app.engine.TestState

private val DURATIONS = listOf(60, 300, 600, 1800, 3600, 7200, 21600)

@Composable
fun DurationPicker(title: String, sec: Int, enabled: Boolean, onChange: (Int) -> Unit) {
    Label(title)
    Gap(4.dp)
    Chips(DURATIONS, sec, { fmtDur(it) }, enabled = enabled) { onChange(it) }
    Gap(6.dp)
    var txt by remember(sec) { mutableStateOf((sec / 60).toString()) }
    OutlinedTextField(
        value = txt,
        onValueChange = { v ->
            val f = v.filter { ch -> ch.isDigit() }.take(4)
            txt = f
            val m = f.toIntOrNull()
            if (m != null && m in 1..1440) onChange(m * 60)
        },
        label = { Text("Custom (minutes, 1 to 1440)") },
        singleLine = true,
        enabled = enabled,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun LongRunScreen(ui: UiPrefs, onServers: () -> Unit, onOpenReport: (String) -> Unit) {
    val ctx = LocalContext.current
    val live by TestState.live.collectAsState()
    val mine = live.running && live.kind == "long"
    val busyOther = live.running && live.kind != "long"
    val rep = rememberLatest("long")
    val total = Plans.totalSec(Plans.build(ui.mode, ui.longSec, ui.longUpSec))

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp)) {
        ScreenHeader("Long Run", null)
        ServerCard(ui.server.name, ui.server.loc, onServers)
        Gap(10.dp)

        if (mine) {
            LiveRun(live, ui)
            Gap(14.dp)
            PrimaryButton("Stop and save partial result", { TestService.stop(ctx) }, Modifier.fillMaxWidth(), color = C.Red)
            Gap(8.dp)
            Label("Keeps running with the screen off (foreground notification). The result is saved when it ends or you stop it.")
        } else {
            Panel {
                Title("Mode")
                Gap(8.dp)
                ModeGrid(
                    listOf(RunMode.BOTH, RunMode.SEQUENTIAL, RunMode.DOWNLOAD, RunMode.UPLOAD), ui.mode,
                    { when (it) { RunMode.BOTH -> "Both"; RunMode.SEQUENTIAL -> "Both"; RunMode.DOWNLOAD -> "Download"; RunMode.UPLOAD -> "Upload" } },
                    { when (it) { RunMode.BOTH -> "(Simultaneous)"; RunMode.SEQUENTIAL -> "(Sequential)"; else -> "Only" } }
                ) { ui.updateMode(it) }
                Gap(6.dp)
                Label(ui.mode.hint)
                Gap(14.dp)
                if (ui.mode == RunMode.SEQUENTIAL) {
                    DurationPicker("Download duration", ui.longSec, true) { ui.updateLongSec(it) }
                    Gap(14.dp)
                    DurationPicker("Upload duration", ui.longUpSec, true) { ui.updateLongUpSec(it) }
                } else {
                    DurationPicker("Duration", ui.longSec, true) { ui.updateLongSec(it) }
                }
                Gap(14.dp)
                Label("Connections (download / upload)")
                Segmented(ConnType.values().toList(), ui.conn, { it.label }) { ui.updateConn(it) }
            }
            Gap(12.dp)
            Notice("Long runs transfer data continuously. Use Wi-Fi or an unlimited plan.")
            Gap(12.dp)
            val err = live.error
            if (err != null) { Notice(err, C.Red); Gap(12.dp) }
            if (busyOther) { Notice("A ${kindLabel(live.kind)} is running. Wait for it to finish first."); Gap(12.dp) }
            PrimaryButton(
                "Start Long Run  (total ${fmtDur(total)})",
                { TestService.start(ctx, RunConfig("long", ui.mode, ui.longSec, ui.longUpSec, ui.conn, ui.server)) },
                Modifier.fillMaxWidth(), enabled = !busyOther
            )
            Gap(14.dp)
            Panel {
                Title("Display")
                Gap(8.dp)
                Label("Unit")
                Segmented(SpeedUnit.values().toList(), ui.unit, { it.label }) { ui.updateUnit(it) }
                Gap(10.dp)
                Label("Gauge scale (Mbps)")
                Segmented(GaugeScale.values().toList(), ui.scale, { it.label }) { ui.updateScale(it) }
            }
            if (rep != null) {
                Gap(14.dp)
                ResultCard(rep, ui.unit, onOpenReport)
            }
        }
        Gap(24.dp)
    }
}
