package com.speedscope.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.speedscope.app.data.History
import com.speedscope.app.data.Prefs
import com.speedscope.app.data.Report
import com.speedscope.app.engine.TestState
import com.speedscope.app.ui.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SpeedScopeTheme { AppRoot() } }
    }
}

/** Full-screen pages pushed over the 4 main tabs. */
sealed class Screen {
    object Servers : Screen()
    object History : Screen()
    class Report(val id: String) : Screen()
    class Session(val id: Long) : Screen()
    class Tool(val name: String) : Screen()
}

private val TABS = listOf("⚡" to "Speed", "⏱" to "Long Run", "📡" to "Monitor", "🧰" to "Tools")

@Composable
fun AppRoot() {
    val ctx = LocalContext.current
    val ui = remember { UiPrefs(Prefs(ctx)) }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val stack = remember { mutableStateListOf<Screen>() }
    val top: Screen? = stack.lastOrNull()

    fun push(s: Screen) { stack.add(s) }
    fun pop() { if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex) }

    BackHandler(enabled = stack.isNotEmpty()) { pop() }

    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    Scaffold(
        containerColor = C.Bg,
        bottomBar = {
            if (top == null) {
                NavigationBar(containerColor = C.Card) {
                    TABS.forEachIndexed { i, t ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Text(t.first, fontSize = 20.sp) },
                            label = { Text(t.second, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = C.Card2, selectedTextColor = C.Text, unselectedTextColor = C.Muted
                            )
                        )
                    }
                }
            }
        }
    ) { inner ->
        Box(Modifier.padding(inner).fillMaxSize()) {
            when (top) {
                null -> when (tab) {
                    0 -> SpeedScreen(ui, { push(Screen.Servers) }, { push(Screen.Report(it)) })
                    1 -> LongRunScreen(ui, { push(Screen.Servers) }, { push(Screen.Report(it)) })
                    2 -> MonitorScreen(ui, { push(Screen.Session(it)) }, { push(Screen.History) })
                    else -> ToolsScreen({ push(Screen.Tool(it)) }, { push(Screen.History) }, { push(Screen.Servers) })
                }
                is Screen.Servers -> ServerScreen(ui) { pop() }
                is Screen.History -> HistoryScreen(
                    ui, { pop() }, { push(Screen.Report(it)) }, { push(Screen.Session(it)) }
                )
                is Screen.Report -> ReportLoader(top.id, ui, { pop() })
                is Screen.Session -> MonitorReportScreen(top.id, { pop() }, { pop() })
                is Screen.Tool -> when (top.name) {
                    "latency" -> LatencyScreen { pop() }
                    "signal" -> SignalScreen { pop() }
                    "scan" -> ScanScreen { pop() }
                    else -> VideoScreen(ui, { pop() }, { push(Screen.Report(it)) })
                }
            }
        }
    }
}

@Composable
private fun ReportLoader(id: String, ui: UiPrefs, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var report by remember(id) { mutableStateOf<Report?>(null) }
    var loaded by remember(id) { mutableStateOf(false) }
    LaunchedEffect(id) {
        report = withContext(Dispatchers.IO) { History.get(ctx, id) ?: TestState.last.value?.takeIf { it.id == id } }
        loaded = true
    }
    val r = report
    if (r != null) {
        ReportDetailScreen(r, ui.unit, onClose, onClose)
    } else {
        Column(Modifier.padding(16.dp)) {
            ScreenHeader("Report", onClose)
            Label(if (loaded) "This report no longer exists." else "Loading…")
        }
    }
}
