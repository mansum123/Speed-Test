package com.speedscope.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** SpeedScope palette. Download = green, Upload = orange, Ping = purple (same colours in the PDF/PNG reports). */
object C {
    val Bg = Color(0xFFF3F6FB)
    val Card = Color(0xFFFFFFFF)
    val Card2 = Color(0xFFE6ECF6)
    val Grid = Color(0xFFD3DBE8)
    val Text = Color(0xFF0F172A)
    val Muted = Color(0xFF5B6B85)
    val Blue = Color(0xFF1E6BFF)
    val BlueLight = Color(0xFF3FA4FF)
    val Green = Color(0xFF10B981)
    val Orange = Color(0xFFF59E0B)
    val Purple = Color(0xFF8B5CF6)
    val Red = Color(0xFFEF4444)
    val Teal = Color(0xFF14B8A6)
}

@Composable
fun SpeedScopeTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = C.Blue,
            onPrimary = Color.White,
            background = C.Bg,
            onBackground = C.Text,
            surface = C.Card,
            onSurface = C.Text,
            surfaceVariant = C.Card2,
            onSurfaceVariant = C.Muted,
            error = C.Red
        ),
        content = content
    )
}
