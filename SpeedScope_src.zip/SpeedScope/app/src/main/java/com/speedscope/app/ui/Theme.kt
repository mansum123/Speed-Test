package com.speedscope.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** SpeedScope palette. Download = green, Upload = orange, Ping = purple (same colours in the PDF/PNG reports). */
object C {
    val Bg = Color(0xFF0B1220)
    val Card = Color(0xFF131C2E)
    val Card2 = Color(0xFF1B2740)
    val Grid = Color(0xFF2A3754)
    val Text = Color(0xFFE5EAF3)
    val Muted = Color(0xFF8B98B0)
    val Blue = Color(0xFF3B82F6)
    val Green = Color(0xFF10B981)
    val Orange = Color(0xFFF59E0B)
    val Purple = Color(0xFF8B5CF6)
    val Red = Color(0xFFEF4444)
    val Teal = Color(0xFF14B8A6)
}

@Composable
fun SpeedScopeTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = C.Blue,
            onPrimary = Color.White,
            background = C.Bg,
            onBackground = C.Text,
            surface = C.Card,
            onSurface = C.Text,
            surfaceVariant = C.Card2,
            onSurfaceVariant = C.Muted,
            error = C.Red
        ),
        content = content
    )
}
