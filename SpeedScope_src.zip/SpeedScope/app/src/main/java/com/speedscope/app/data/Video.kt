package com.speedscope.app.data

data class Quality(val label: String, val needMbps: Double)

/** Video quality ladder. A level is "OK" when the weak-moment speed (P10) has 25% headroom over the bitrate. */
object VideoLadder {
    val ladder = listOf(
        Quality("240p", 0.4), Quality("360p", 0.7), Quality("480p", 1.1), Quality("720p", 2.5),
        Quality("1080p", 5.0), Quality("1440p", 9.0), Quality("4K", 20.0)
    )
    const val HEADROOM = 1.25

    fun weakSpeed(downMbps: List<Double>): Double = percentile(steady(downMbps).sorted(), 10.0)

    fun supports(q: Quality, weakMbps: Double): Boolean = weakMbps >= q.needMbps * HEADROOM

    fun best(downMbps: List<Double>): Quality? {
        val weak = weakSpeed(downMbps)
        return ladder.lastOrNull { supports(it, weak) }
    }
}
