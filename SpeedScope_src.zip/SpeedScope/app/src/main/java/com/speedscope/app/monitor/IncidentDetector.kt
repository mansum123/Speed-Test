package com.speedscope.app.monitor

/**
 * Pure logic, no Android dependencies.
 * - fewer than [threshold] consecutive failures = "dropped probes" (not an outage)
 * - [threshold] or more consecutive failures = outage, starting at the FIRST failed probe
 * - recovery on first successful probe
 */
class Incident(
    val startMs: Long,
    var endMs: Long? = null,
    var fails: Int = 0,
    val beforeMs: Double? = null,
    var afterMs: Double? = null,
    var diag: String? = null
)

enum class EvType { STARTED, RECOVERED }
class DetEvent(val type: EvType, val incident: Incident)

class IncidentDetector(private val threshold: Int = 3) {
    val incidents = ArrayList<Incident>()
    var total = 0; private set
    var ok = 0; private set
    var droppedProbes = 0; private set

    private var consecutive = 0
    private var firstFailMs = 0L
    private var lastOkRtt: Double? = null
    private var current: Incident? = null
    private var lastT = 0L

    val isOutage: Boolean get() = current != null

    /** rtt == null means the probe failed. */
    fun onProbe(tMs: Long, rtt: Double?): DetEvent? {
        lastT = tMs
        total++
        if (rtt == null) {
            consecutive++
            if (consecutive == 1) firstFailMs = tMs
            val cur = current
            if (cur != null) {
                cur.fails = consecutive
            } else if (consecutive >= threshold) {
                val inc = Incident(firstFailMs, null, consecutive, lastOkRtt, null)
                incidents.add(inc)
                current = inc
                return DetEvent(EvType.STARTED, inc)
            }
            return null
        }
        ok++
        var ev: DetEvent? = null
        val cur = current
        if (cur != null) {
            cur.endMs = tMs
            cur.fails = consecutive
            cur.afterMs = rtt
            current = null
            ev = DetEvent(EvType.RECOVERED, cur)
        } else if (consecutive in 1 until threshold) {
            droppedProbes += consecutive
        }
        consecutive = 0
        lastOkRtt = rtt
        return ev
    }

    /** Called on pause/stop: closes an open outage at the last probe time, resets the streak. */
    fun interrupt() {
        val cur = current
        if (cur != null) {
            cur.endMs = lastT
            cur.fails = consecutive
            current = null
        } else if (consecutive in 1 until threshold) {
            droppedProbes += consecutive
        }
        consecutive = 0
    }

    /** Percent of successful probes; paused time is excluded because no probes are sent. */
    val availability: Double get() = if (total == 0) 100.0 else ok * 100.0 / total
}
