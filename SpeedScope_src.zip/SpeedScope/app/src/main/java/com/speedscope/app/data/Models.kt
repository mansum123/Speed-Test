package com.speedscope.app.data

enum class RunMode(val label: String, val hint: String) {
    DOWNLOAD("Download", "Only download"),
    UPLOAD("Upload", "Only upload"),
    BOTH("Both", "Download + upload at the same time"),
    SEQUENTIAL("Sequential", "Download first, then upload (separate durations)")
}

enum class Dir { DOWN, UP, BOTH }

data class Phase(val dir: Dir, val seconds: Int)

object Plans {
    fun build(mode: RunMode, primarySec: Int, uploadSec: Int): List<Phase> = when (mode) {
        RunMode.DOWNLOAD -> listOf(Phase(Dir.DOWN, primarySec))
        RunMode.UPLOAD -> listOf(Phase(Dir.UP, primarySec))
        RunMode.BOTH -> listOf(Phase(Dir.BOTH, primarySec))
        RunMode.SEQUENTIAL -> listOf(Phase(Dir.DOWN, primarySec), Phase(Dir.UP, uploadSec))
    }

    fun totalSec(phases: List<Phase>): Int {
        var s = 0
        for (p in phases) s += p.seconds
        return s
    }
}

enum class SpeedUnit(val label: String, val perMbps: Double) {
    MBPS("Mbps", 1.0), MBYTES("MB/s", 0.125), GBPS("Gbps", 0.001), KBPS("Kbps", 1000.0)
}

enum class GaugeScale(val label: String, val max: Double) {
    AUTO("Auto", 0.0), S100("100", 100.0), S500("500", 500.0), S1000("1000", 1000.0)
}

enum class ConnType(val label: String, val down: Int, val up: Int) {
    MULTI("Multi (10/4)", 10, 4), SINGLE("Single (1/1)", 1, 1)
}

/** One second of measurement. down/up in Mbps, ping in ms (negative = no value). */
data class Sample(val t: Int, val down: Double, val up: Double, val ping: Double)

data class NetSnap(
    val type: String = "",
    val ssid: String = "",
    val rssi: Int = 0,
    val linkMbps: Int = 0,
    val freqMhz: Int = 0,
    val gateway: String = "",
    val gatewayMs: Double = -1.0,
    val dnsMs: Double = -1.0
)

data class Report(
    val id: String,
    val kind: String,           // "speed" or "long"
    val startedAt: Long,
    val mode: RunMode,
    val conn: ConnType,
    val phases: List<Phase>,
    val server: String,
    val serverLoc: String,
    val samples: List<Sample>,
    val idlePingMs: Double,
    val snap: NetSnap,
    val partial: Boolean
)

fun Report.dirAt(t: Int): Dir {
    var acc = 0
    for (p in phases) {
        acc += p.seconds
        if (t <= acc) return p.dir
    }
    return phases.lastOrNull()?.dir ?: Dir.DOWN
}

fun Report.downValues(): List<Double> = samples.filter { dirAt(it.t) != Dir.UP }.map { it.down }
fun Report.upValues(): List<Double> = samples.filter { dirAt(it.t) != Dir.DOWN }.map { it.up }
fun Report.pings(): List<Double> = samples.map { it.ping }.filter { it >= 0 }
val Report.hasDown: Boolean get() = phases.any { it.dir != Dir.UP }
val Report.hasUp: Boolean get() = phases.any { it.dir != Dir.DOWN }
