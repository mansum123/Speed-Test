package com.speedscope.app.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.speedscope.app.data.*
import com.speedscope.app.engine.Server

/** Compose-observable wrapper around [Prefs]: every change is written to disk immediately. */
class UiPrefs(private val p: Prefs) {
    var unit by mutableStateOf(p.unit); private set
    var scale by mutableStateOf(p.scale); private set
    var conn by mutableStateOf(p.conn); private set
    var mode by mutableStateOf(p.mode); private set
    var longSec by mutableStateOf(p.longSec); private set
    var longUpSec by mutableStateOf(p.longUpSec); private set
    var server by mutableStateOf(p.server); private set
    var monTarget by mutableStateOf(p.monTarget); private set
    var monCustom by mutableStateOf(p.monCustom); private set
    var monInterval by mutableStateOf(p.monIntervalSec); private set

    fun updateUnit(v: SpeedUnit) { unit = v; p.unit = v }
    fun updateScale(v: GaugeScale) { scale = v; p.scale = v }
    fun updateConn(v: ConnType) { conn = v; p.conn = v }
    fun updateMode(v: RunMode) { mode = v; p.mode = v }
    fun updateLongSec(v: Int) { longSec = v; p.longSec = v }
    fun updateLongUpSec(v: Int) { longUpSec = v; p.longUpSec = v }
    fun updateServer(v: Server) { server = v; p.server = v }
    fun updateMonTarget(v: String) { monTarget = v; p.monTarget = v }
    fun updateMonCustom(v: String) { monCustom = v; p.monCustom = v }
    fun updateMonInterval(v: Int) { monInterval = v; p.monIntervalSec = v }

    /** Host the monitor will probe ("gateway" is resolved by the service itself). */
    fun monHost(): String = if (monTarget == "custom") monCustom.trim() else monTarget
}
