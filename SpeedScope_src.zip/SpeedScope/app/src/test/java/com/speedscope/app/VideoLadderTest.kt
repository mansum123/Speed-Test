package com.speedscope.app

import com.speedscope.app.data.*
import org.junit.Assert.*
import org.junit.Test

class VideoLadderTest {
    @Test fun fastStableLineSupports4K() = assertEquals("4K", VideoLadder.best(List(15) { 100.0 })!!.label)

    @Test fun weakMomentsLimitQuality() {
        // average is high but P10 is low -> must not claim 4K
        val v = List(15) { if (it in 4..6) 3.0 else 100.0 }
        val best = VideoLadder.best(v)!!
        assertTrue(VideoLadder.ladder.indexOf(best) < VideoLadder.ladder.size - 1)
    }
    @Test fun tinySpeedGivesNothing() = assertNull(VideoLadder.best(List(15) { 0.2 }))
    @Test fun headroomApplied() {
        val q = Quality("x", 4.0)
        assertFalse(VideoLadder.supports(q, 4.5)); assertTrue(VideoLadder.supports(q, 5.0))
    }
}
