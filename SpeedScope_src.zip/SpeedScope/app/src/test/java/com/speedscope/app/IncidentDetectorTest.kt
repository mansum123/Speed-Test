package com.speedscope.app

import com.speedscope.app.monitor.*
import org.junit.Assert.*
import org.junit.Test

class IncidentDetectorTest {
    @Test fun twoFailsAreDroppedProbesNotOutage() {
        val d = IncidentDetector(3)
        d.onProbe(1000, 10.0); d.onProbe(2000, null); d.onProbe(3000, null); d.onProbe(4000, 12.0)
        assertEquals(0, d.incidents.size); assertEquals(2, d.droppedProbes)
        assertEquals(4, d.total); assertEquals(2, d.ok); assertEquals(50.0, d.availability, 1e-9)
    }
    @Test fun threeFailsOpenIncidentAtFirstFail() {
        val d = IncidentDetector(3)
        d.onProbe(1000, 10.0)
        assertNull(d.onProbe(2000, null)); assertNull(d.onProbe(3000, null))
        val ev = d.onProbe(4000, null)
        assertEquals(EvType.STARTED, ev!!.type)
        assertEquals(2000L, ev.incident.startMs); assertEquals(10.0, ev.incident.beforeMs!!, 1e-9)
        assertTrue(d.isOutage)
    }
    @Test fun recoveryClosesIncident() {
        val d = IncidentDetector(3)
        d.onProbe(1000, 10.0)
        d.onProbe(2000, null); d.onProbe(3000, null); d.onProbe(4000, null); d.onProbe(5000, null)
        val ev = d.onProbe(6000, 25.0)
        assertEquals(EvType.RECOVERED, ev!!.type)
        val i = d.incidents.single()
        assertEquals(6000L, i.endMs); assertEquals(4, i.fails); assertEquals(25.0, i.afterMs!!, 1e-9)
        assertFalse(d.isOutage)
    }
    @Test fun interruptClosesOpenIncident() {
        val d = IncidentDetector(3)
        d.onProbe(1000, null); d.onProbe(2000, null); d.onProbe(3000, null)
        d.interrupt()
        assertEquals(3000L, d.incidents.single().endMs); assertFalse(d.isOutage)
    }
    @Test fun availabilityWithNoProbesIs100() = assertEquals(100.0, IncidentDetector().availability, 1e-9)
}
