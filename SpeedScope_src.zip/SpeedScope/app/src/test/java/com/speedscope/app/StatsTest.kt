package com.speedscope.app

import com.speedscope.app.data.*
import org.junit.Assert.*
import org.junit.Test

class StatsTest {
    @Test fun statsBasic() {
        val s = statsOf(listOf(10.0, 20.0, 30.0, 40.0, 50.0))
        assertEquals(30.0, s.avg, 1e-9); assertEquals(10.0, s.min, 1e-9)
        assertEquals(50.0, s.max, 1e-9); assertEquals(30.0, s.median, 1e-9)
        assertEquals(5, s.n)
    }
    @Test fun statsEmpty() = assertEquals(0, statsOf(emptyList()).n)

    @Test fun percentileInterpolates() {
        assertEquals(15.0, percentile(listOf(10.0, 20.0), 50.0), 1e-9)
        assertEquals(10.0, percentile(listOf(10.0, 20.0), 0.0), 1e-9)
    }

    @Test fun steadyDropsWarmup() {
        assertEquals(listOf(4.0, 5.0, 6.0), steady(listOf(1.0, 2.0, 3.0, 4.0, 5.0, 6.0)))
        assertEquals(listOf(1.0, 2.0), steady(listOf(1.0, 2.0)))
    }

    @Test fun jitterIgnoresNoReply() {
        assertEquals(5.0, jitter(listOf(10.0, 15.0, -1.0, 10.0)), 1e-9)
        assertEquals(0.0, jitter(listOf(10.0)), 1e-9)
    }

    @Test fun boostDetectsReduction() {
        val v = List(30) { 100.0 } + List(50) { 50.0 }
        val b = boostOf(v)!!
        assertEquals(100.0, b.first, 1e-9); assertEquals(50.0, b.after, 1e-9)
        assertEquals(50.0, b.dropPct, 1e-9); assertTrue(b.reduced)
    }
    @Test fun boostStableIsNotReduced() = assertFalse(boostOf(List(100) { 80.0 })!!.reduced)
    @Test fun boostNeedsEnoughData() = assertNull(boostOf(List(40) { 80.0 }))

    @Test fun downsampleKeepsExtremesAndSize() {
        val v = List(5000) { if (it == 2500) 999.0 else if (it == 3100) -5.0 else 10.0 }
        val d = downsampleMinMax(v, 600)
        assertTrue(d.size <= 600); assertEquals(999.0, d.max(), 1e-9); assertEquals(-5.0, d.min(), 1e-9)
    }
    @Test fun downsampleShortUnchanged() = assertEquals(listOf(1.0, 2.0), downsampleMinMax(listOf(1.0, 2.0), 600))

    @Test fun formatters() {
        assertEquals("5 min", fmtDur(300)); assertEquals("1 hr", fmtDur(3600))
        assertEquals("1 hr 5 min", fmtDur(3900)); assertEquals("45 s", fmtDur(45))
        assertEquals("2:05", fmtClock(125))
        assertEquals("12.5", fmtSpeed(12.5, SpeedUnit.MBPS)); assertEquals("1.56", fmtSpeed(12.5, SpeedUnit.MBYTES))
    }

    @Test fun planSequentialHasTwoPhases() {
        val p = Plans.build(RunMode.SEQUENTIAL, 300, 120)
        assertEquals(2, p.size); assertEquals(Dir.DOWN, p[0].dir); assertEquals(120, p[1].seconds)
        assertEquals(420, Plans.totalSec(p))
        assertEquals(1, Plans.build(RunMode.BOTH, 60, 0).size)
    }
}
